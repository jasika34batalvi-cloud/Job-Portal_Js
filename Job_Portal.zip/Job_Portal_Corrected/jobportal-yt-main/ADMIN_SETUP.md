# Administrator setup and feature notes

## Create the first administrator
For security, public signup accepts only `student` and `recruiter`. It cannot create an administrator account.

1. Register a normal user account from the website.
2. In MongoDB Atlas / Compass, open the `users` collection for this project database.
3. Find that user's document by email and change only `role` to `admin`.
4. Log out and sign in again, selecting the administrator account.
5. Open `/admin/dashboard`.

The backend admin APIs require a valid login token and `role: "admin"`:
- `GET /api/v1/admin/dashboard`
- `GET /api/v1/admin/verification-queue`
- `PATCH /api/v1/admin/companies/:id/verification` with `{ "status": "verified" }` or `{ "status": "rejected", "note": "Reason" }`

## Included features
- Persistent light/dark theme toggle in the top navigation.
- Redesigned landing page with responsive feature cards, CTA section and Framer Motion entrance/scroll animations.
- Resume Match Analyzer. This is a local keyword-based demo that compares pasted resume text with a job description; it does not claim to use a hosted generative AI model. TXT upload is supported. PDF/DOCX extraction or a real AI provider can be added with a configured backend service.
- Admin dashboard with live MongoDB counts, recent jobs and recruiter company verification queue.
- Company verification status fields: `pending`, `verified`, `rejected`.

## Important
Existing company records are compatible: Mongoose applies the `pending` default to new company records. This update adds verification metadata and an admin review workflow; it does not automatically hide existing/public jobs or claim legal identity verification. Admins should check submitted company information before approving it.
