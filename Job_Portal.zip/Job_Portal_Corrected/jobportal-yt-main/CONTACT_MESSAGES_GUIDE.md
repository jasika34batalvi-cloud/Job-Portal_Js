# Contact messages workflow

1. Start the MongoDB-backed backend and frontend as described in README.md.
2. Sign in as a normal user/student or recruiter and open Contact. The account name and email are attached automatically; the user cannot spoof them through the form.
3. Submit a subject and message (minimum 10 characters). The message is stored in the `contactmessages` MongoDB collection with the sender's `userId`.
4. Sign in with an account whose role is `admin` and open **Admin Dashboard → Contact Messages**, or visit `/admin/contact-messages`.
5. Admin can open a message, mark it read/resolved, refresh the inbox, search messages, and delete messages.

The contact API is protected by the existing JWT cookie/Bearer authentication middleware. Admin listing, status updates and deletion additionally require role `admin`.

API endpoints:
- `POST /api/v1/contact` (authenticated): `{ "subject": "Help", "message": "I need help with my account." }`
- `GET /api/v1/contact/admin/messages` (admin)
- `PATCH /api/v1/contact/admin/messages/:id/status` (admin): `{ "status": "read" }` or `resolved` / `new`
- `DELETE /api/v1/contact/admin/messages/:id` (admin)
