import mongoose from "mongoose";

const assessmentSchema = new mongoose.Schema({
  recruiter: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  application: { type: mongoose.Schema.Types.ObjectId, ref: "Application", required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 120 },
  instructions: { type: String, required: true, trim: true, maxlength: 5000 },
  dueAt: { type: Date, default: null },
  response: { type: String, default: "", maxlength: 20000 },
  submittedAt: { type: Date, default: null },
  score: { type: Number, min: 0, max: 100, default: null },
  reviewerFeedback: { type: String, default: "", maxlength: 3000 },
  status: { type: String, enum: ["assigned", "submitted", "reviewed"], default: "assigned" }
}, { timestamps: true });

export const Assessment = mongoose.model("Assessment", assessmentSchema);
