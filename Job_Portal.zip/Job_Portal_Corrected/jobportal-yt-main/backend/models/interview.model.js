import mongoose from "mongoose";
const interviewSchema = new mongoose.Schema({
 student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
 recruiter: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
 job: { type: mongoose.Schema.Types.ObjectId, ref: "Job", default: null },
 title: { type: String, required: true, trim: true, maxlength: 160 },
 company: { type: String, default: "", trim: true, maxlength: 120 },
 scheduledAt: { type: Date, required: true },
 durationMinutes: { type: Number, default: 30, min: 10, max: 240 },
 location: { type: String, default: "Online", trim: true, maxlength: 250 },
 notes: { type: String, default: "", maxlength: 2000 },
 status: { type: String, enum: ["pending", "accepted", "declined", "completed", "cancelled"], default: "pending" },
}, { timestamps: true });
export const Interview = mongoose.model("Interview", interviewSchema);
