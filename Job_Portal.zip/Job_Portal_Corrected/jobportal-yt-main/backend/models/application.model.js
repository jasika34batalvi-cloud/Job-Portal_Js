import mongoose from "mongoose";

const applicationSchema = new mongoose.Schema(
  {
    job: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Job",
      required: true,
    },
    applicant: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    status: {
      type: String,
      enum: ["pending", "accepted", "rejected"],
      default: "pending",
    },
    pipelineStage: {
      type: String,
      enum: ["Applied", "Shortlisted", "Assessment", "Interview", "Offer", "Hired", "Rejected"],
      default: "Applied",
    },
    candidateNotes: [{
      author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
      text: { type: String, required: true, trim: true, maxlength: 2000 },
      createdAt: { type: Date, default: Date.now }
    }],
    interviewFeedback: [{
      author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
      rating: { type: Number, min: 1, max: 5, required: true },
      comments: { type: String, trim: true, maxlength: 3000, default: "" },
      createdAt: { type: Date, default: Date.now }
    }],
  },
  { timestamps: true }
);

applicationSchema.index({ job: 1, applicant: 1 }, { unique: true });

export const Application = mongoose.model("Application", applicationSchema);
