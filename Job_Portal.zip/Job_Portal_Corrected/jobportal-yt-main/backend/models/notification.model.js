import mongoose from "mongoose";
const notificationSchema = new mongoose.Schema({
 user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
 title: { type: String, required: true, trim: true },
 message: { type: String, required: true, trim: true },
 type: { type: String, enum: ["application", "interview", "assessment", "system"], default: "system" },
 read: { type: Boolean, default: false },
 link: { type: String, default: "/profile" },
}, { timestamps: true });
export const Notification = mongoose.model("Notification", notificationSchema);
