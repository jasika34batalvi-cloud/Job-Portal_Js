import mongoose from "mongoose";
import { Notification } from "../models/notification.model.js";
import { Interview } from "../models/interview.model.js";
import { Application } from "../models/application.model.js";
import { Job } from "../models/job.model.js";
import { User } from "../models/user.model.js";

export const listNotifications = async (req, res) => {
 try { const items = await Notification.find({ user: req.id }).sort({ createdAt: -1 }).limit(100); res.json({ success: true, notifications: items }); }
 catch (e) { res.status(500).json({ success: false, message: "Unable to load notifications." }); }
};
export const markNotificationRead = async (req, res) => {
 try { const item = await Notification.findOneAndUpdate({ _id: req.params.id, user: req.id }, { read: true }, { new: true }); if (!item) return res.status(404).json({ success: false, message: "Notification not found." }); res.json({ success: true, notification: item }); }
 catch (e) { res.status(400).json({ success: false, message: "Invalid notification id." }); }
};
export const markAllNotificationsRead = async (req, res) => {
 try { await Notification.updateMany({ user: req.id, read: false }, { read: true }); res.json({ success: true, message: "All notifications marked as read." }); }
 catch (e) { res.status(500).json({ success: false, message: "Unable to update notifications." }); }
};
export const listInterviews = async (req, res) => {
 try {
  const filter = req.user.role === "recruiter" ? { recruiter: req.id } : { student: req.id };
  const interviews = await Interview.find(filter).populate("job", "title").populate("student", "fullname email").sort({ scheduledAt: 1 });
  res.json({ success: true, interviews });
 } catch (e) { res.status(500).json({ success: false, message: "Unable to load interview calendar." }); }
};

export const listRecruiterCandidates = async (req, res) => {
 try {
  const jobs = await Job.find({ created_by: req.id }).select("_id title company").populate("company", "name");
  const jobIds = jobs.map(j => j._id);
  const applications = await Application.find({ job: { $in: jobIds } })
   .populate("applicant", "fullname email phoneNumber profile")
   .populate({ path: "job", select: "title company", populate: { path: "company", select: "name" } })
   .sort({ createdAt: -1 });
  const candidates = applications.filter(a => a.applicant && a.job).map(a => ({
   applicationId: a._id, createdAt: a.createdAt, studentId: a.applicant._id, studentName: a.applicant.fullname || a.applicant.email,
   studentEmail: a.applicant.email,
   studentPhone: a.applicant.phoneNumber || "",
   studentSkills: a.applicant.profile?.skills || [],
   resume: a.applicant.profile?.resume || "",
   resumeOriginalName: a.applicant.profile?.resumeOriginalName || "",
   profilePhoto: a.applicant.profile?.profilePhoto || "",
   bio: a.applicant.profile?.bio || "",
   jobId: a.job._id, jobTitle: a.job.title, applicationStatus: a.status,
   pipelineStage: a.pipelineStage || "Applied",
   candidateNotes: a.candidateNotes || [],
   interviewFeedback: a.interviewFeedback || [],
   company: a.job.company?.name || ""
  }));
  res.json({ success: true, candidates });
 } catch (e) { res.status(500).json({ success: false, message: "Unable to load applicants for your jobs." }); }
};

export const createInterview = async (req, res) => {
 try {
  if (req.user.role !== "recruiter") return res.status(403).json({ success: false, message: "Only recruiters can send interview invitations." });
  const { title, company, scheduledAt, durationMinutes, location, notes, studentId, jobId } = req.body;
  if (!title?.trim() || !studentId || !jobId || !mongoose.isValidObjectId(studentId) || !mongoose.isValidObjectId(jobId) || !scheduledAt || Number.isNaN(new Date(scheduledAt).getTime()) || new Date(scheduledAt) <= new Date()) {
   return res.status(400).json({ success: false, message: "Choose an applicant and provide an interview title and future date/time." });
  }
  const ownedJob = await Job.findOne({ _id: jobId, created_by: req.id });
  if (!ownedJob) return res.status(403).json({ success: false, message: "Select one of your own jobs." });
  const application = await Application.findOne({ job: jobId, applicant: studentId });
  if (!application) return res.status(400).json({ success: false, message: "This student has not applied to the selected job." });
  const student = await User.findById(studentId).select("_id");
  if (!student) return res.status(404).json({ success: false, message: "Student account not found." });
  const interview = await Interview.create({ student: studentId, recruiter: req.id, job: jobId, title: title.trim(), company: company || "", scheduledAt: new Date(scheduledAt), durationMinutes: durationMinutes || 30, location: location || "Online", notes: notes || "", status: "pending" });
  const when = new Date(interview.scheduledAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
  await Notification.create({
   user: studentId,
   title: "Interview invitation received",
   message: `${interview.title} for ${ownedJob.title} is proposed for ${when}. Duration: ${interview.durationMinutes} minutes. Location: ${interview.location || "Online"}. Please review and accept or decline in Interviews.`,
   type: "interview",
   link: "/interviews"
  });
  res.status(201).json({ success: true, message: "Interview invitation sent to student.", interview });
 } catch (e) { console.error("CREATE INTERVIEW ERROR", e); res.status(500).json({ success: false, message: "Unable to schedule interview." }); }
};

export const updateInterview = async (req, res) => {
 try {
  const { status } = req.body;
  const isRecruiter = req.user.role === "recruiter";
  const allowed = isRecruiter ? ["completed", "cancelled"] : ["accepted", "declined"];
  if (!allowed.includes(status)) return res.status(400).json({ success: false, message: `Allowed status values: ${allowed.join(", ")}.` });
  const filter = isRecruiter ? { recruiter: req.id } : { student: req.id, status: "pending" };
  const item = await Interview.findOneAndUpdate({ _id: req.params.id, ...filter }, { status }, { new: true, runValidators: true }).populate("job", "title").populate("student", "fullname email");
  if (!item) return res.status(404).json({ success: false, message: "Pending interview invitation not found." });
  if (item.recruiter) {
   const who = item.student?.fullname || "The student";
   const msg = status === "accepted" ? `${who} accepted the interview invitation for ${new Date(item.scheduledAt).toLocaleString("en-IN")}.` : `${who} declined the proposed interview time. Please arrange another time if needed.`;
   if (isRecruiter) {
    await Notification.create({ user: item.student._id, title: status === "completed" ? "Interview completed" : "Interview cancelled", message: `Your interview “${item.title}” has been marked ${status}.`, type: "interview", link: "/interviews" });
   } else {
    await Notification.create({ user: item.recruiter, title: `Interview ${status}`, message: msg, type: "interview", link: "/interviews" });
   }
  }
  res.json({ success: true, interview: item, message: `Interview ${status}.` });
 } catch (e) { console.error("UPDATE INTERVIEW ERROR", e); res.status(400).json({ success: false, message: "Unable to update interview." }); }
};
export const createStatusNotification = async (application, status) => {
 try { await Notification.create({ user: application.applicant, title: "Application status updated", message: `Your application status is now ${status}.`, type: "application", link: "/applications" }); } catch (e) { console.error("NOTIFICATION ERROR", e.message); }
};
