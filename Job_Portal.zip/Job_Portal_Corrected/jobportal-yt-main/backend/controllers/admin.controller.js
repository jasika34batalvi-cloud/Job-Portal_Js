import { User } from "../models/user.model.js";
import { Company } from "../models/company.model.js";
import { Job } from "../models/job.model.js";
import { Application } from "../models/application.model.js";
import mongoose from "mongoose";

export const getAdminDashboard = async (req, res) => {
  try {
    const [students, recruiters, companies, jobs, applications, pendingCompanies, recentJobs] = await Promise.all([
      User.countDocuments({ role: "student" }), User.countDocuments({ role: "recruiter" }),
      Company.countDocuments(), Job.countDocuments(), Application.countDocuments(),
      Company.countDocuments({ verificationStatus: "pending" }),
      Job.find().sort({ createdAt: -1 }).limit(6).populate("company", "name verificationStatus")
    ]);
    const monthly = await Application.aggregate([
      { $match: { createdAt: { $gte: new Date(Date.now() - 180 * 86400000) } } },
      { $group: { _id: { $dateToString: { format: "%Y-%m", date: "$createdAt" } }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);
    res.json({ success: true, stats: { students, recruiters, companies, jobs, applications, pendingCompanies }, monthly, recentJobs });
  } catch (error) { console.error("ADMIN DASHBOARD:", error); res.status(500).json({ success: false, message: "Unable to load admin dashboard." }); }
};

export const getVerificationQueue = async (req, res) => {
  try {
    const companies = await Company.find({ verificationStatus: "pending" }).populate("userId", "fullname email").sort({ createdAt: 1 });
    res.json({ success: true, companies });
  } catch (error) { res.status(500).json({ success: false, message: "Unable to load verification queue." }); }
};

export const reviewCompany = async (req, res) => {
  try {
    const { status, note = "" } = req.body;
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid company id." });
    if (!["verified", "rejected"].includes(status)) return res.status(400).json({ success: false, message: "Status must be verified or rejected." });
    const company = await Company.findByIdAndUpdate(req.params.id, {
      verificationStatus: status, verificationNote: String(note).slice(0, 500), verifiedAt: status === "verified" ? new Date() : null
    }, { new: true, runValidators: true });
    if (!company) return res.status(404).json({ success: false, message: "Company not found." });
    res.json({ success: true, message: `Company ${status}.`, company });
  } catch (error) { res.status(500).json({ success: false, message: "Unable to review company." }); }
};
