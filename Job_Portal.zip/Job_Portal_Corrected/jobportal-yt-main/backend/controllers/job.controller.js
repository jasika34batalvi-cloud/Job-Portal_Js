import mongoose from "mongoose";
import { Job } from "../models/job.model.js";
import { Company } from "../models/company.model.js";
import { User } from "../models/user.model.js";

export const postJob = async (req, res) => {
  try {
    const {
      title,
      description,
      requirements,
      salary,
      location,
      jobType,
      category,
      workMode,
      experience,
      position,
      companyId,
    } = req.body;

    if (
      !title?.trim() ||
      !description?.trim() ||
      !requirements?.toString().trim() ||
      salary === undefined ||
      salary === "" ||
      !location?.trim() ||
      !jobType?.trim() ||
      experience === undefined ||
      experience === "" ||
      position === undefined ||
      position === "" ||
      !companyId
    ) {
      return res.status(400).json({
        success: false,
        message: "All job fields are required.",
      });
    }

    if (!mongoose.isValidObjectId(companyId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid company id.",
      });
    }

    const company = await Company.findOne({
      _id: companyId,
      userId: req.id,
    });

    if (!company) {
      return res.status(403).json({
        success: false,
        message: "You can only post jobs for your own company.",
      });
    }

    const job = await Job.create({
      title: title.trim(),
      description: description.trim(),
      requirements: Array.isArray(requirements)
        ? requirements.map((item) => String(item).trim()).filter(Boolean)
        : String(requirements)
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean),
      salary: Number(salary),
      location: location.trim(),
      jobType: jobType.trim(),
      category: String(category || "").trim(),
      workMode: String(workMode || "").trim(),
      experienceLevel: Number(experience),
      position: Number(position),
      company: companyId,
      created_by: req.id,
    });

    return res.status(201).json({
      success: true,
      message: "New job created successfully.",
      job,
    });
  } catch (error) {
    console.error("POST JOB ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to create job.",
    });
  }
};

export const getAllJobs = async (req, res) => {
  try {
    const escapeRegex = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const query = {};
    const keyword = String(req.query.keyword || "").trim();
    if (keyword) {
      const term = new RegExp(escapeRegex(keyword), "i");
      query.$or = [
        { title: term }, { description: term }, { location: term },
        { category: term }, { requirements: term }, { jobType: term }
      ];
    }

    if (req.query.jobType) query.jobType = new RegExp(`^${escapeRegex(req.query.jobType)}$`, "i");
    if (req.query.location) query.location = new RegExp(escapeRegex(req.query.location), "i");
    if (req.query.category) {
      const term = new RegExp(escapeRegex(req.query.category), "i");
      query.$and = [...(query.$and || []), { $or: [{ category: term }, { title: term }, { requirements: term }] }];
    }
    if (req.query.workMode) query.workMode = new RegExp(`^${escapeRegex(req.query.workMode)}$`, "i");
    if (req.query.skills) {
      const skills = String(req.query.skills).split(",").map((item) => item.trim()).filter(Boolean);
      if (skills.length) query.requirements = { $in: skills.map((skill) => new RegExp(escapeRegex(skill), "i")) };
    }

    if (req.query.salary) {
      const [min, max] = String(req.query.salary).split("-");
      if (String(req.query.salary).endsWith("+")) query.salary = { $gte: Number(String(req.query.salary).slice(0, -1)) };
      else query.salary = { ...(min !== "" ? { $gte: Number(min) } : {}), ...(max !== "" ? { $lte: Number(max) } : {}) };
    }
    if (req.query.experience) {
      const value = String(req.query.experience);
      if (value.endsWith("+")) query.experienceLevel = { $gte: Number(value.slice(0, -1)) };
      else if (value.includes("-")) {
        const [min, max] = value.split("-");
        query.experienceLevel = { $gte: Number(min), $lte: Number(max) };
      } else query.experienceLevel = Number(value);
    }
    if (req.query.postedWithin) {
      const days = Number(req.query.postedWithin);
      if (Number.isFinite(days) && days > 0 && days <= 365) query.createdAt = { $gte: new Date(Date.now() - days * 24 * 60 * 60 * 1000) };
    }
    if (req.query.company) {
      const companies = await Company.find({ name: new RegExp(escapeRegex(req.query.company), "i") }).select("_id");
      query.company = { $in: companies.map((company) => company._id) };
    }

    const sortMap = { newest: { createdAt: -1 }, oldest: { createdAt: 1 }, salaryHigh: { salary: -1, createdAt: -1 }, salaryLow: { salary: 1, createdAt: -1 } };
    const sort = sortMap[req.query.sort] || sortMap.newest;
    const jobs = await Job.find(query).populate("company").sort(sort).limit(200);
    return res.status(200).json({ success: true, jobs });
  } catch (error) {
    console.error("GET JOBS ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to fetch jobs." });
  }
};

export const getJobById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid job id.",
      });
    }

    const job = await Job.findById(req.params.id)
      .populate("company")
      .populate("applications");

    if (!job) {
      return res.status(404).json({
        success: false,
        message: "Job not found.",
      });
    }

    return res.status(200).json({
      success: true,
      job,
    });
  } catch (error) {
    console.error("GET JOB ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch job.",
    });
  }
};

export const getAdminJobs = async (req, res) => {
  try {
    const jobs = await Job.find({
      created_by: req.id,
    })
      .populate("company")
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      jobs,
    });
  } catch (error) {
    console.error("GET ADMIN JOBS ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch recruiter jobs.",
    });
  }
};


export const saveJob = async (req, res) => {
  try {
    const jobId = req.params.id;

    if (!mongoose.isValidObjectId(jobId)) {
      return res.status(400).json({ success: false, message: "Invalid job id." });
    }

    const job = await Job.findById(jobId).select("_id");
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found." });
    }

    await User.findByIdAndUpdate(
      req.id,
      { $addToSet: { savedJobs: jobId } },
      { runValidators: true }
    );

    return res.status(200).json({
      success: true,
      message: "Job saved for later.",
      jobId,
    });
  } catch (error) {
    console.error("SAVE JOB ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to save job.",
    });
  }
};

export const unsaveJob = async (req, res) => {
  try {
    const jobId = req.params.id;

    if (!mongoose.isValidObjectId(jobId)) {
      return res.status(400).json({ success: false, message: "Invalid job id." });
    }

    await User.findByIdAndUpdate(req.id, { $pull: { savedJobs: jobId } });

    return res.status(200).json({
      success: true,
      message: "Job removed from saved jobs.",
      jobId,
    });
  } catch (error) {
    console.error("UNSAVE JOB ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to remove saved job.",
    });
  }
};

export const getSavedJobs = async (req, res) => {
  try {
    const user = await User.findById(req.id).populate({
      path: "savedJobs",
      populate: { path: "company" },
    });

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found." });
    }

    return res.status(200).json({
      success: true,
      jobs: user.savedJobs || [],
    });
  } catch (error) {
    console.error("GET SAVED JOBS ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch saved jobs.",
    });
  }
};
