import { ContactMessage } from "../models/contactMessage.model.js";
import { User } from "../models/user.model.js";
import mongoose from "mongoose";

export const createContactMessage = async (req, res) => {
  try {
    const { subject, message } = req.body || {};
    if (typeof subject !== "string" || typeof message !== "string" || !subject.trim() || !message.trim()) {
      return res.status(400).json({ success: false, message: "Please enter a subject and message." });
    }
    if (subject.trim().length < 3 || subject.length > 120 || message.trim().length < 10 || message.length > 3000) {
      return res.status(400).json({ success: false, message: "Subject must be 3–120 characters and message 10–3000 characters." });
    }
    const sender = await User.findById(req.id).select("fullname email");
    if (!sender) return res.status(401).json({ success: false, message: "Please login again to send a message." });
    await ContactMessage.create({ userId: sender._id, name: sender.fullname, email: sender.email, subject: subject.trim(), message: message.trim() });
    return res.status(201).json({ success: true, message: "Your message has been sent successfully. The admin can now view it." });
  } catch (error) {
    console.error("CONTACT MESSAGE ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to save your message. Please try again." });
  }
};

export const getContactMessages = async (_req, res) => {
  try {
    const messages = await ContactMessage.find().sort({ createdAt: -1 }).lean();
    const counts = await ContactMessage.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]);
    return res.json({ success: true, messages, counts: Object.fromEntries(counts.map((x) => [x._id, x.count])) });
  } catch (error) {
    console.error("GET CONTACT MESSAGES ERROR:", error);
    return res.status(500).json({ success: false, message: "Unable to load contact messages." });
  }
};

export const updateContactMessageStatus = async (req, res) => {
  try {
    const { status } = req.body || {};
    if (!["new", "read", "resolved"].includes(status)) return res.status(400).json({ success: false, message: "Invalid message status." });
    const item = await ContactMessage.findByIdAndUpdate(req.params.id, { status }, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ success: false, message: "Message not found." });
    return res.json({ success: true, message: "Message status updated.", item });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to update message." });
  }
};

export const deleteContactMessage = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid message ID." });
    const item = await ContactMessage.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: "Message not found." });
    return res.json({ success: true, message: "Contact message deleted." });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to delete message." });
  }
};
