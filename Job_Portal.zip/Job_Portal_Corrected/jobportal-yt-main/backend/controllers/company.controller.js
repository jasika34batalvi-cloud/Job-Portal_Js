import mongoose from "mongoose";
import { Company } from "../models/company.model.js";
import { Job } from "../models/job.model.js";
import { Application } from "../models/application.model.js";
import { User } from "../models/user.model.js";

export const registerCompany = async (req, res) => {
  try {
    const { companyName } = req.body;

    if (!companyName?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Company name is required.",
      });
    }

    const name = companyName.trim();

    const existingCompany = await Company.findOne({
      name: { $regex: `^${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, $options: "i" },
    });

    if (existingCompany) {
      return res.status(409).json({
        success: false,
        message: "A company with this name already exists.",
      });
    }

    const company = await Company.create({
      name,
      userId: req.id,
    });

    return res.status(201).json({
      success: true,
      message: "Company registered successfully.",
      company,
    });
  } catch (error) {
    console.error("REGISTER COMPANY ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to register company.",
    });
  }
};

export const getCompany = async (req, res) => {
  try {
    const companies = await Company.find({ userId: req.id }).sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      companies,
    });
  } catch (error) {
    console.error("GET COMPANIES ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch companies.",
    });
  }
};

export const getCompanyById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid company id.",
      });
    }

    const company = await Company.findOne({
      _id: req.params.id,
      userId: req.id,
    });

    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found.",
      });
    }

    return res.status(200).json({
      success: true,
      company,
    });
  } catch (error) {
    console.error("GET COMPANY ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to fetch company.",
    });
  }
};

export const updateCompany = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid company id.",
      });
    }

    const { name, description, website, location, logo } = req.body;

    const company = await Company.findOneAndUpdate(
      {
        _id: req.params.id,
        userId: req.id,
      },
      {
        ...(name !== undefined && { name: name.trim() }),
        ...(description !== undefined && { description }),
        ...(website !== undefined && { website }),
        ...(location !== undefined && { location }),
        ...(logo !== undefined && { logo }),
      },
      { new: true, runValidators: true }
    );

    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Company information updated.",
      company,
    });
  } catch (error) {
    console.error("UPDATE COMPANY ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to update company.",
    });
  }
};


export const deleteCompany = async (req, res) => {
  try {
    const companyId = req.params.id;

    if (!mongoose.isValidObjectId(companyId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid company id.",
      });
    }

    const company = await Company.findOne({
      _id: companyId,
      userId: req.id,
    });

    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found or you do not own this company.",
      });
    }

    const jobs = await Job.find({ company: companyId }).select("_id");
    const jobIds = jobs.map((job) => job._id);

    if (jobIds.length) {
      await Application.deleteMany({ job: { $in: jobIds } });
      await User.updateMany({}, { $pull: { savedJobs: { $in: jobIds } } });
      await Job.deleteMany({ _id: { $in: jobIds } });
    }

    await Company.deleteOne({ _id: companyId });

    return res.status(200).json({
      success: true,
      message: "Company and its jobs deleted successfully.",
      deletedCompanyId: companyId,
      deletedJobs: jobIds.length,
    });
  } catch (error) {
    console.error("DELETE COMPANY ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to delete company.",
    });
  }
};

