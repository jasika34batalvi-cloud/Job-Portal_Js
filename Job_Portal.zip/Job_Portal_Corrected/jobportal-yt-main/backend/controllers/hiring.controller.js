import mongoose from "mongoose";
import { Application } from "../models/application.model.js";
import { Job } from "../models/job.model.js";
import { Assessment } from "../models/assessment.model.js";
import { Notification } from "../models/notification.model.js";

const STAGES = ["Applied", "Shortlisted", "Assessment", "Interview", "Offer", "Hired", "Rejected"];
const ownedApplication = async (applicationId, recruiterId) => {
  if (!mongoose.isValidObjectId(applicationId)) return null;
  const application = await Application.findById(applicationId);
  if (!application) return null;
  const job = await Job.findOne({ _id: application.job, created_by: recruiterId });
  return job ? { application, job } : null;
};

export const getHiringAnalytics = async (req, res) => {
  try {
    const jobs = await Job.find({ created_by: req.id }).select("_id title");
    const jobIds = jobs.map((job) => job._id);
    const applications = await Application.find({ job: { $in: jobIds } })
      .select("status pipelineStage createdAt");
    const stages = Object.fromEntries(STAGES.map((stage) => [
      stage,
      applications.filter((a) => (a.pipelineStage || "Applied") === stage).length,
    ]));
    const assessments = await Assessment.find({ recruiter: req.id }).select("status score");
    const interviews = stages.Interview || 0;
    const hired = stages.Hired || 0;
    const rejected = stages.Rejected || 0;
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);
    const newThisMonth = applications.filter((a) => a.createdAt >= monthStart).length;

    // Last six calendar months, including the current month.
    const monthlyApplications = Array.from({ length: 6 }, (_, index) => {
      const date = new Date();
      date.setDate(1);
      date.setHours(0, 0, 0, 0);
      date.setMonth(date.getMonth() - (5 - index));
      const next = new Date(date);
      next.setMonth(next.getMonth() + 1);
      return {
        month: date.toLocaleString("en-IN", { month: "short" }),
        applications: applications.filter((a) => a.createdAt >= date && a.createdAt < next).length,
      };
    });

    res.json({
      success: true,
      analytics: {
        totalJobs: jobs.length,
        totalCandidates: applications.length,
        newThisMonth,
        interviews,
        hired,
        rejected,
        shortlisted: stages.Shortlisted || 0,
        hireRate: applications.length ? Math.round((hired / applications.length) * 100) : 0,
        assessmentAssigned: assessments.length,
        assessmentsAssigned: assessments.length,
        assessmentsSubmitted: assessments.filter((a) => ["submitted", "reviewed"].includes(a.status)).length,
        averageAssessmentScore: (() => {
          const reviewed = assessments.filter((a) => a.status === "reviewed" && Number.isFinite(a.score));
          return reviewed.length ? Math.round(reviewed.reduce((sum, a) => sum + a.score, 0) / reviewed.length) : 0;
        })(),
        stages,
        monthlyApplications,
      },
    });
  } catch (error) {
    console.error("HIRING ANALYTICS ERROR:", error);
    res.status(500).json({ success: false, message: "Unable to load hiring analytics." });
  }
};

export const updatePipelineStage = async (req, res) => {
  try {
    const { stage } = req.body;
    if (!STAGES.includes(stage)) return res.status(400).json({ success: false, message: "Choose a valid hiring stage." });
    const found = await ownedApplication(req.params.id, req.id);
    if (!found) return res.status(404).json({ success: false, message: "Candidate application not found for your jobs." });
    found.application.pipelineStage = stage;
    if (stage === "Rejected") found.application.status = "rejected";
    else if (["Offer", "Hired"].includes(stage)) found.application.status = "accepted";
    else found.application.status = "pending";
    await found.application.save();
    try {
      await Notification.create({
        user: found.application.applicant,
        title: "Hiring progress updated",
        message: `Your application for ${found.job.title} has moved to: ${stage}.`,
        type: "application",
        link: "/applications"
      });
    } catch (notificationError) {
      console.error("PIPELINE NOTIFICATION ERROR:", notificationError.message);
    }
    res.json({ success: true, message: "Hiring stage updated.", application: found.application });
  } catch (error) {
    console.error("UPDATE PIPELINE ERROR:", error);
    res.status(500).json({ success: false, message: "Unable to update hiring stage." });
  }
};

export const addCandidateNote = async (req, res) => {
  try {
    const text = String(req.body.text || "").trim();
    if (!text || text.length > 2000) return res.status(400).json({ success: false, message: "Enter a note of up to 2,000 characters." });
    const found = await ownedApplication(req.params.id, req.id);
    if (!found) return res.status(404).json({ success: false, message: "Candidate application not found for your jobs." });
    found.application.candidateNotes.push({ author: req.id, text });
    await found.application.save();
    res.status(201).json({ success: true, message: "Candidate note saved.", notes: found.application.candidateNotes });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to save candidate note." });
  }
};

export const addInterviewFeedback = async (req, res) => {
  try {
    const rating = Number(req.body.rating);
    const comments = String(req.body.comments || "").trim();
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ success: false, message: "Rating must be from 1 to 5." });
    const found = await ownedApplication(req.params.id, req.id);
    if (!found) return res.status(404).json({ success: false, message: "Candidate application not found for your jobs." });
    found.application.interviewFeedback.push({ author: req.id, rating, comments });
    await found.application.save();
    res.status(201).json({ success: true, message: "Interview feedback saved.", feedback: found.application.interviewFeedback });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to save interview feedback." });
  }
};

export const listAssessments = async (req, res) => {
  try {
    const filter = req.user.role === "recruiter" ? { recruiter: req.id } : { application: { $in: (await Application.find({ applicant: req.id }).distinct("_id")) } };
    const assessments = await Assessment.find(filter)
      .populate({ path: "application", populate: [{ path: "applicant", select: "fullname email" }, { path: "job", select: "title" }] })
      .sort({ createdAt: -1 });
    res.json({ success: true, assessments });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load assessments." });
  }
};

export const createAssessment = async (req, res) => {
  try {
    const { applicationId, title, instructions, dueAt } = req.body;
    if (!mongoose.isValidObjectId(applicationId) || !String(title || "").trim() || !String(instructions || "").trim()) {
      return res.status(400).json({ success: false, message: "Select a candidate and provide an assessment title and instructions." });
    }
    const found = await ownedApplication(applicationId, req.id);
    if (!found) return res.status(404).json({ success: false, message: "Candidate application not found for your jobs." });
    let dueDate = null;
    if (dueAt) {
      dueDate = new Date(dueAt);
      if (Number.isNaN(dueDate.getTime())) return res.status(400).json({ success: false, message: "Invalid due date." });
    }
    const assessment = await Assessment.create({ recruiter: req.id, application: applicationId, title: String(title).trim(), instructions: String(instructions).trim(), dueAt: dueDate });
    found.application.pipelineStage = "Assessment";
    await found.application.save();
    try {
      await Notification.create({
        user: found.application.applicant,
        title: "New assignment received",
        message: `You have been assigned “${assessment.title}” for ${found.job.title}.`,
        type: "assessment",
        link: "/assessments",
      });
    } catch (notificationError) {
      // The assignment is already saved; a notification failure must not
      // make the recruiter see a false assignment failure.
      console.error("ASSESSMENT NOTIFICATION ERROR:", notificationError);
    }

    res.status(201).json({
      success: true,
      message: "Assignments sent successfully!",
      assessment,
    });
  } catch (error) {
    console.error("CREATE ASSESSMENT ERROR:", error);
    res.status(500).json({ success: false, message: "Unable to assign assessment." });
  }
};

export const submitAssessment = async (req, res) => {
  try {
    const response = String(req.body.response || "").trim();
    if (!response) return res.status(400).json({ success: false, message: "Write your response before submitting." });
    const assessment = await Assessment.findOne({ _id: req.params.id, status: "assigned" }).populate("application");
    if (!assessment || !assessment.application || String(assessment.application.applicant) !== String(req.id)) {
      return res.status(404).json({ success: false, message: "Assigned assessment not found." });
    }
    if (assessment.dueAt && assessment.dueAt < new Date()) return res.status(400).json({ success: false, message: "The assessment due date has passed." });
    assessment.response = response;
    assessment.submittedAt = new Date();
    assessment.status = "submitted";
    await assessment.save();
    await Notification.create({ user: assessment.recruiter, title: "Assessment submitted", message: `A candidate has submitted “${assessment.title}”.`, type: "assessment", link: "/admin/hiring" });
    res.json({ success: true, message: "Assessment submitted successfully.", assessment });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to submit assessment." });
  }
};

export const reviewAssessment = async (req, res) => {
  try {
    const score = Number(req.body.score);
    const reviewerFeedback = String(req.body.reviewerFeedback || "").trim();
    if (!Number.isInteger(score) || score < 0 || score > 100) return res.status(400).json({ success: false, message: "Score must be between 0 and 100." });
    const assessment = await Assessment.findOneAndUpdate(
      { _id: req.params.id, recruiter: req.id, status: "submitted" },
      { score, reviewerFeedback, status: "reviewed" },
      { new: true, runValidators: true }
    ).populate("application");
    if (!assessment) return res.status(404).json({ success: false, message: "Submitted assessment not found." });
    await Notification.create({ user: assessment.application.applicant, title: "Assessment reviewed", message: `Your assessment “${assessment.title}” has been reviewed. Score: ${score}/100.`, type: "assessment", link: "/assessments" });
    res.json({ success: true, message: "Assessment reviewed.", assessment });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to review assessment." });
  }
};


export const deleteAssessment = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid assessment id." });
    }
    const assessment = await Assessment.findOneAndDelete({
      _id: req.params.id,
      recruiter: req.id,
    });
    if (!assessment) {
      return res.status(404).json({ success: false, message: "Assessment not found or you do not have permission to delete it." });
    }
    res.json({ success: true, message: "Assessment deleted successfully." });
  } catch (error) {
    console.error("DELETE ASSESSMENT ERROR:", error);
    res.status(500).json({ success: false, message: "Unable to delete assessment." });
  }
};
