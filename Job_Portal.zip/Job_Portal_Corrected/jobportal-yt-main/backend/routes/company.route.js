import express from "express";
import isAuthenticated from "../middlewares/isAuthenticated.js";
import requireRole from "../middlewares/requireRole.js";
import {
  getCompany,
  getCompanyById,
  registerCompany,
  updateCompany,
  deleteCompany,
} from "../controllers/company.controller.js";

const router = express.Router();

router.use(isAuthenticated, requireRole("recruiter"));

router.post("/register", registerCompany);
router.get("/get", getCompany);
router.get("/get/:id", getCompanyById);
router.put("/update/:id", updateCompany);
router.delete("/delete/:id", deleteCompany);

export default router;
