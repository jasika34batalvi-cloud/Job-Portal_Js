import express from "express";
import isAuthenticated from "../middlewares/isAuthenticated.js";
import requireRole from "../middlewares/requireRole.js";
import {
  getAdminJobs,
  getAllJobs,
  getJobById,
  postJob,
  saveJob,
  unsaveJob,
  getSavedJobs,
} from "../controllers/job.controller.js";

const router = express.Router();

router.get("/get", getAllJobs);
router.get("/get/:id", getJobById);

router.post("/save/:id", isAuthenticated, requireRole("student"), saveJob);
router.delete("/save/:id", isAuthenticated, requireRole("student"), unsaveJob);
router.get("/saved", isAuthenticated, requireRole("student"), getSavedJobs);

router.post(
  "/post",
  isAuthenticated,
  requireRole("recruiter"),
  postJob
);

router.get(
  "/getadminjobs",
  isAuthenticated,
  requireRole("recruiter"),
  getAdminJobs
);

export default router;
