import express from "express";
import isAuthenticated from "../middlewares/isAuthenticated.js";
import requireRole from "../middlewares/requireRole.js";
import { createContactMessage, getContactMessages, updateContactMessageStatus, deleteContactMessage } from "../controllers/contact.controller.js";

const router = express.Router();
router.post("/", isAuthenticated, createContactMessage);
router.get("/admin/messages", isAuthenticated, requireRole("admin"), getContactMessages);
router.patch("/admin/messages/:id/status", isAuthenticated, requireRole("admin"), updateContactMessageStatus);
router.delete("/admin/messages/:id", isAuthenticated, requireRole("admin"), deleteContactMessage);
export default router;
