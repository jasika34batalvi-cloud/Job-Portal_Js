# Repair notes

This ZIP contains the repaired Job Portal source.

## Repairs included
- Removed accidental literal `\n` text from JavaScript/JSX source files that caused Vite/esbuild syntax errors.
- Restored the `/admin/dashboard` route and connected it to the admin-only route guard.
- Corrected the admin/recruiter/student navigation links.
- Reworked the Home page and theme-toggle Navbar with valid line breaks.
- Updated the frontend page title and metadata.
- Kept the MongoDB/JWT backend and mounted the admin API route.

## Run on Windows

Open two terminals.

Terminal 1:
```powershell
cd backend
copy .env.example .env
npm install
npm run dev
```

Edit `backend/.env` and enter your MongoDB Atlas connection string and a strong JWT secret.

Terminal 2:
```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The backend health check is `http://localhost:8000/api/health`.

Do not use placeholder credentials in `.env`; enter your own MongoDB URI and JWT secret.
