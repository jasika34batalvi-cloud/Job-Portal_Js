import React, { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import { CalendarDays, Bell, CheckCheck, MapPin, Clock3, Users, Video, CheckCircle2, XCircle, CalendarPlus, BriefcaseBusiness, RefreshCw } from "lucide-react";
import Navbar from "./shared/Navbar";
import { useSelector } from "react-redux";
import { CAREER_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";

const initial = { title: "Interview", company: "", scheduledAt: "", durationMinutes: 30, location: "Online meeting", notes: "", candidateKey: "" };
const dateTime = (value) => value ? new Date(value).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "Date to be confirmed";

const NotificationsCalendar = () => {
  const { user } = useSelector((s) => s.auth);
  const isRecruiter = user?.role === "recruiter";
  const [notifications, setNotifications] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [form, setForm] = useState(initial);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const requests = [
        axios.get(`${CAREER_API_END_POINT}/notifications`, { withCredentials: true }),
        axios.get(`${CAREER_API_END_POINT}/interviews`, { withCredentials: true }),
      ];
      if (isRecruiter) requests.push(axios.get(`${CAREER_API_END_POINT}/candidates`, { withCredentials: true }));
      const results = await Promise.all(requests);
      setNotifications(results[0].data.notifications || []);
      setInterviews(results[1].data.interviews || []);
      setCandidates(isRecruiter ? results[2]?.data.candidates || [] : []);
    } catch (e) {
      toast.error(e.response?.data?.message || "Could not load interviews and notifications.");
    } finally { setLoading(false); }
  }, [isRecruiter]);

  useEffect(() => { load(); }, [load]);
  const selectedCandidate = useMemo(() => candidates.find((c) => c.applicationId === form.candidateKey), [candidates, form.candidateKey]);
  const pendingCount = interviews.filter((i) => i.status === "pending").length;
  const unreadCount = notifications.filter((n) => !n.read).length;

  const submit = async (e) => {
    e.preventDefault();
    if (!selectedCandidate) return toast.error("Choose a student who applied to one of your jobs.");
    setSaving(true);
    try {
      await axios.post(`${CAREER_API_END_POINT}/interviews`, {
        title: form.title, company: form.company, scheduledAt: new Date(form.scheduledAt).toISOString(),
        durationMinutes: Number(form.durationMinutes), location: form.location, notes: form.notes,
        studentId: selectedCandidate.studentId, jobId: selectedCandidate.jobId,
      }, { withCredentials: true });
      toast.success("Invitation sent! The student can accept or decline the proposed time.");
      setForm(initial); await load();
    } catch (e) { toast.error(e.response?.data?.message || "Unable to send interview invitation."); }
    finally { setSaving(false); }
  };

  const updateInterview = async (id, status) => {
    try {
      const res = await axios.patch(`${CAREER_API_END_POINT}/interviews/${id}`, { status }, { withCredentials: true });
      toast.success(res.data.message || `Interview ${status}.`); await load();
    } catch (e) { toast.error(e.response?.data?.message || "Unable to update interview."); }
  };

  const markRead = async (id) => {
    try { await axios.patch(`${CAREER_API_END_POINT}/notifications/${id}/read`, {}, { withCredentials: true }); setNotifications((old) => old.map((n) => n._id === id ? { ...n, read: true } : n)); }
    catch { toast.error("Could not update notification."); }
  };
  const markAll = async () => {
    try { await axios.patch(`${CAREER_API_END_POINT}/notifications/read-all`, {}, { withCredentials: true }); setNotifications((old) => old.map((n) => ({ ...n, read: true }))); toast.success("All notifications marked as read."); }
    catch { toast.error("Could not update notifications."); }
  };

  const statusStyle = {
    pending: "bg-amber-50 text-amber-700 ring-amber-200",
    accepted: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    declined: "bg-rose-50 text-rose-700 ring-rose-200",
    completed: "bg-sky-50 text-sky-700 ring-sky-200",
    cancelled: "bg-slate-100 text-slate-600 ring-slate-200",
  };

  return <div className="min-h-screen bg-slate-50/80"><Navbar />
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-700 via-indigo-700 to-slate-900 p-6 text-white shadow-xl sm:p-9">
        <div className="absolute -right-10 -top-16 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl"><span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold tracking-widest"><CalendarDays size={14}/>{isRecruiter ? "RECRUITER WORKSPACE" : "CAREER ORGANIZER"}</span>
            <h1 className="mt-4 text-3xl font-black tracking-tight sm:text-4xl">{isRecruiter ? "Interview scheduling" : "Your interviews & updates"}</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-indigo-100 sm:text-base">{isRecruiter ? "Invite applicants to an interview, propose a date and time, and track each student's response." : "Review recruiter invitations, accept a suitable interview time, and keep every important update in one place."}</p>
          </div>
          <button onClick={load} className="inline-flex w-fit items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-4 py-2.5 text-sm font-semibold hover:bg-white/20"><RefreshCw size={16}/> Refresh</button>
        </div>
        <div className="relative mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
          {[{ label: isRecruiter ? "Invitations sent" : "Interview invitations", value: interviews.length, icon: CalendarDays }, { label: "Awaiting response", value: pendingCount, icon: Clock3 }, { label: "Unread notifications", value: unreadCount, icon: Bell }].map(({ label, value, icon: Icon }) => <div key={label} className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur-sm"><div className="flex items-center justify-between text-indigo-100"><span className="text-sm">{label}</span><Icon size={18}/></div><p className="mt-2 text-3xl font-extrabold">{value}</p></div>)}
        </div>
      </section>

      {isRecruiter && <section className="mt-7 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-start gap-3 border-b border-slate-100 px-5 py-5 sm:px-7"><div className="rounded-xl bg-violet-100 p-3 text-violet-700"><CalendarPlus size={22}/></div><div><h2 className="text-xl font-extrabold text-slate-900">Send an interview invitation</h2><p className="mt-1 text-sm text-slate-500">Only applicants for jobs you posted can be invited. The student must accept or decline.</p></div></div>
        <form onSubmit={submit} className="grid gap-4 p-5 sm:grid-cols-2 sm:p-7">
          <label className="text-sm font-semibold text-slate-700 sm:col-span-2">Applicant and job<select required value={form.candidateKey} onChange={(e) => { const key = e.target.value; const candidate = candidates.find((c) => c.applicationId === key); setForm((old) => ({ ...old, candidateKey: key, title: candidate ? `${candidate.jobTitle} Interview` : "Interview", company: candidate?.company || "" })); }} className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white p-3.5 font-normal outline-none transition focus:border-violet-500 focus:ring-4 focus:ring-violet-100"><option value="">Choose an applicant…</option>{candidates.map((c) => <option key={c.applicationId} value={c.applicationId}>{c.studentName} · {c.jobTitle} ({c.applicationStatus})</option>)}</select>{candidates.length === 0 && <span className="mt-1 block text-xs font-normal text-amber-700">No applicants found for your jobs yet. Create a job and wait for a student application.</span>}</label>
          <label className="text-sm font-semibold text-slate-700">Interview title<input required maxLength={160} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Frontend Developer Interview" className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"/></label>
          <label className="text-sm font-semibold text-slate-700">Company name<input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} placeholder="Company name" className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"/></label>
          <label className="text-sm font-semibold text-slate-700">Proposed date and time<input required type="datetime-local" min={new Date(Date.now() + 60000).toISOString().slice(0, 16)} value={form.scheduledAt} onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })} className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"/></label>
          <label className="text-sm font-semibold text-slate-700">Duration<select value={form.durationMinutes} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"><option value={15}>15 minutes</option><option value={30}>30 minutes</option><option value={45}>45 minutes</option><option value={60}>60 minutes</option><option value={90}>90 minutes</option><option value={120}>2 hours</option></select></label>
          <label className="text-sm font-semibold text-slate-700">Location / meeting link<input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Office address or video link" className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"/></label>
          <label className="text-sm font-semibold text-slate-700">Notes for student<textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="Topics to prepare, documents to bring…" className="mt-1.5 w-full resize-y rounded-xl border border-slate-200 p-3.5 font-normal outline-none focus:border-violet-500 focus:ring-4 focus:ring-violet-100"/></label>
          <div className="flex flex-wrap items-center gap-3 sm:col-span-2"><button disabled={saving || !candidates.length} className="inline-flex items-center justify-center gap-2 rounded-xl bg-violet-600 px-5 py-3 font-bold text-white shadow-lg shadow-violet-200 transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-50"><Video size={17}/>{saving ? "Sending invitation…" : "Send invitation to student"}</button><span className="text-xs text-slate-500">The student receives a notification and can accept or decline.</span></div>
        </form>
      </section>}

      <div className="mt-7 grid items-start gap-6 lg:grid-cols-[1.15fr_.85fr]">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="flex items-center gap-2 text-xl font-extrabold text-slate-900"><CalendarDays className="text-violet-600" size={22}/>{isRecruiter ? "Interview invitations" : "Upcoming interviews"}</h2><p className="mt-1 text-sm text-slate-500">{isRecruiter ? "See whether applicants have responded." : "Accept or decline proposed dates from recruiters."}</p></div><span className="rounded-full bg-violet-50 px-3 py-1.5 text-sm font-bold text-violet-700">{interviews.length}</span></div>
          {loading ? <div className="animate-pulse space-y-3">{[1,2].map((n) => <div key={n} className="h-28 rounded-xl bg-slate-100"/>)}</div> : interviews.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-5 py-12 text-center"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-100 text-violet-600"><CalendarDays size={26}/></div><h3 className="mt-4 font-bold text-slate-900">{isRecruiter ? "No invitations sent yet" : "No interview invitations yet"}</h3><p className="mx-auto mt-1 max-w-sm text-sm leading-6 text-slate-500">{isRecruiter ? "Choose one of your applicants above to propose an interview date and time." : "When a recruiter schedules an interview, it will appear here with options to accept or decline."}</p></div> : <div className="space-y-3">{interviews.map((i) => <article key={i._id} className="rounded-2xl border border-slate-200 p-4 transition hover:border-violet-200 hover:shadow-sm sm:p-5"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="font-extrabold text-slate-900">{i.title}</h3><span className={`rounded-full px-2.5 py-1 text-xs font-bold ring-1 ring-inset ${statusStyle[i.status] || statusStyle.pending}`}>{i.status === "pending" ? "Awaiting response" : i.status}</span></div><p className="mt-1 text-sm text-slate-500">{i.company || i.job?.title || "Interview"}</p>{isRecruiter && <p className="mt-1 flex items-center gap-1.5 text-sm font-medium text-slate-700"><Users size={15}/>{i.student?.fullname || i.student?.email || "Applicant"}</p>}</div></div><div className="mt-3 grid gap-2 rounded-xl bg-slate-50 p-3 text-sm text-slate-600 sm:grid-cols-2"><p className="flex items-start gap-2"><Clock3 className="mt-0.5 shrink-0 text-violet-600" size={16}/><span>{dateTime(i.scheduledAt)}<span className="block text-xs text-slate-400">{i.durationMinutes} minutes</span></span></p><p className="flex items-start gap-2 break-all"><MapPin className="mt-0.5 shrink-0 text-violet-600" size={16}/>{i.location || "Online"}</p></div>{i.notes && <p className="mt-3 text-sm leading-6 text-slate-600"><strong className="text-slate-800">Notes: </strong>{i.notes}</p>}
            {!isRecruiter && i.status === "pending" && <div className="mt-4 flex flex-wrap gap-2"><button onClick={() => updateInterview(i._id, "accepted")} className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-700"><CheckCircle2 size={16}/> Accept date & time</button><button onClick={() => updateInterview(i._id, "declined")} className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-bold text-rose-700 hover:bg-rose-50"><XCircle size={16}/> Decline</button></div>}
            {isRecruiter && i.status === "accepted" && <div className="mt-4 flex flex-wrap gap-2"><button onClick={() => updateInterview(i._id, "completed")} className="rounded-xl border border-emerald-200 px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-50">Mark completed</button><button onClick={() => updateInterview(i._id, "cancelled")} className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel interview</button></div>}
          </article>)}</div>}
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="flex items-center gap-2 text-xl font-extrabold text-slate-900"><Bell className="text-violet-600" size={22}/> Notifications</h2><p className="mt-1 text-sm text-slate-500">Application and interview activity</p></div><button onClick={markAll} disabled={!unreadCount} className="inline-flex items-center gap-1.5 rounded-lg px-2 py-2 text-xs font-bold text-violet-700 hover:bg-violet-50 disabled:opacity-40"><CheckCheck size={15}/> Mark all read</button></div>
          {loading ? <p className="py-8 text-center text-sm text-slate-500">Loading notifications…</p> : notifications.length === 0 ? <div className="rounded-2xl bg-slate-50 px-4 py-10 text-center"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm"><Bell size={22}/></div><h3 className="mt-3 font-bold text-slate-900">You're all caught up</h3><p className="mt-1 text-sm leading-6 text-slate-500">Updates will appear here when an application changes or an interview is scheduled.</p></div> : <div className="space-y-2">{notifications.map((n) => <button key={n._id} onClick={() => !n.read && markRead(n._id)} className={`w-full rounded-xl border p-4 text-left transition ${n.read ? "border-slate-100 bg-white" : "border-violet-200 bg-violet-50/70 hover:bg-violet-50"}`}><div className="flex items-start gap-3"><span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${n.read ? "bg-slate-200" : "bg-violet-600"}`}></span><span className="min-w-0"><strong className="block text-sm text-slate-900">{n.title}</strong><span className="mt-1 block text-sm leading-5 text-slate-600">{n.message}</span><span className="mt-2 block text-xs text-slate-400">{dateTime(n.createdAt)}</span></span></div></button>)}</div>}
        </section>
      </div>
      {!isRecruiter && <div className="mt-6 flex items-start gap-3 rounded-2xl border border-indigo-100 bg-indigo-50 p-4 text-sm text-indigo-900"><BriefcaseBusiness className="mt-0.5 shrink-0" size={19}/><p><strong>Track your applications too.</strong> Open <a href="/applications" className="font-bold underline underline-offset-2">Applications</a> in the navigation to view application status and recruiter updates.</p></div>}
    </main>
  </div>;
};
export default NotificationsCalendar;
