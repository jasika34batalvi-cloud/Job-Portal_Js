import React, { useState } from "react";
import { Button } from "./ui/button";
import { Search, Sparkles, BriefcaseBusiness, Users } from "lucide-react";
import { useDispatch } from "react-redux";
import { setSearchedQuery } from "@/redux/jobSlice";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const HeroSection = () => {
  const [query, setQuery] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const searchJobHandler = () => {
    dispatch(setSearchedQuery(query.trim()));
    navigate("/browse");
  };

  return (
    <section className="relative px-4 pt-12 pb-8 sm:pt-20">
      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="absolute left-8 top-20 h-24 w-24 rounded-full bg-purple-200/40 blur-2xl"
      />
      <motion.div
        animate={{ y: [0, 12, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute right-8 top-36 h-28 w-28 rounded-full bg-orange-200/40 blur-2xl"
      />

      <div className="relative mx-auto flex max-w-5xl flex-col items-center gap-7 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 rounded-full border border-purple-100 bg-white px-5 py-2 text-sm font-semibold text-[#F83002] shadow-sm"
        >
          <Sparkles className="h-4 w-4" />
          Find your next opportunity
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-4xl font-extrabold leading-tight sm:text-6xl"
        >
          Search, Apply &{" "}
          <span className="bg-gradient-to-r from-[#6A38C2] to-[#F83002] bg-clip-text text-transparent">
            Get Your Dream Job
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="max-w-2xl text-base text-gray-600 sm:text-lg"
        >
          Discover opportunities from growing companies, apply with confidence,
          and keep your favorite jobs saved for later.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="flex w-full max-w-2xl items-center gap-2 rounded-full border border-gray-200 bg-white p-2 shadow-xl"
        >
          <Search className="ml-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Find your dream job, role or location"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && searchJobHandler()}
            className="w-full bg-transparent px-2 py-3 outline-none"
          />
          <Button
            onClick={searchJobHandler}
            className="rounded-full bg-[#6A38C2] px-6 hover:bg-[#5b30a6]"
          >
            Search
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.45 }}
          className="flex flex-wrap items-center justify-center gap-6 pt-2 text-sm text-gray-600"
        >
          <span className="flex items-center gap-2">
            <BriefcaseBusiness className="h-4 w-4 text-[#6A38C2]" />
            Explore jobs
          </span>
          <span className="flex items-center gap-2">
            <Users className="h-4 w-4 text-[#F83002]" />
            Connect with employers
          </span>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
