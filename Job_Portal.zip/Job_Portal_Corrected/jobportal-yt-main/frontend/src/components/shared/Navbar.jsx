import React from "react";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Button } from "../ui/button";
import { Avatar, AvatarImage } from "../ui/avatar";
import {
  BriefcaseBusiness,
  LogOut,
  User2,
  LayoutDashboard,
  Sun,
  Moon,
  Mail,
  Menu,
  X,
} from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { USER_API_END_POINT } from "@/utils/constant";
import { setUser } from "@/redux/authSlice";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function Navbar() {
  const { user } = useSelector((store) => store.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const isRecruiter = user?.role === "recruiter";
  const isAdmin = user?.role === "admin";

  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const [darkMode, setDarkMode] = React.useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("jobportal-theme") === "dark";
  });

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    window.localStorage.setItem("jobportal-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  const logoutHandler = async () => {
    try {
      const response = await axios.get(`${USER_API_END_POINT}/logout`, {
        withCredentials: true,
      });

      if (response.data?.success) {
        dispatch(setUser(null));
        navigate("/", { replace: true });
        toast.success(response.data.message || "Logged out successfully.");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Unable to logout.");
    }
  };

  const navItems = isAdmin
    ? [
        { label: "Admin Dashboard", to: "/admin/dashboard" },
        { label: "Contact Messages", to: "/admin/contact-messages" },
        { label: "About Us", to: "/about" },
        { label: "Contact", to: "/contact" },
      ]
    : isRecruiter
      ? [
          { label: "Dashboard", to: "/admin/companies" },
          { label: "Jobs", to: "/admin/jobs" },
          { label: "Interviews", to: "/admin/interviews" },
          { label: "Hiring & Analytics", to: "/admin/hiring" },
          { label: "Assignments", to: "/admin/assignments" },
          { label: "About Us", to: "/about" },
          { label: "Contact", to: "/contact" },
        ]
      : [
          { label: "Home", to: "/" },
          { label: "AI Resume Match", to: "/resume-analyzer" },
          { label: "Jobs", to: "/jobs" },
          { label: "Browse", to: "/browse" },
          { label: "Applications", to: "/applications" },
          { label: "Interviews", to: "/interviews" },
          { label: "Prep", to: "/interview-preparation" },
          { label: "Assessments", to: "/assessments" },
          { label: "About Us", to: "/about" },
          { label: "Contact", to: "/contact" },
        ];

  const profileLink = isAdmin
    ? "/admin/dashboard"
    : isRecruiter
      ? "/admin/profile"
      : "/profile";

  return (
    <motion.header
      initial={{ y: -25, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.45 }}
      className="site-header sticky top-0 z-50 border-b border-slate-200/70 bg-white/85 shadow-[0_8px_30px_rgba(76,29,149,0.06)] backdrop-blur-xl"
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-3 px-4 sm:px-6">
        <Link
          to={isAdmin ? "/admin/dashboard" : isRecruiter ? "/admin/companies" : "/"}
          className="group flex shrink-0 items-center gap-2"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-500 text-white shadow-lg shadow-violet-200 transition-transform duration-300 group-hover:rotate-3 group-hover:scale-105">
            <BriefcaseBusiness size={21} />
          </span>
          <span className="text-2xl font-extrabold tracking-tight text-slate-900">
            Job
            <span className="bg-gradient-to-r from-violet-600 to-fuchsia-500 bg-clip-text text-transparent">
              Portal
            </span>
          </span>
        </Link>

        <button type="button" onClick={() => setMobileMenuOpen((open) => !open)} aria-label={mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"} className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-700 lg:hidden">{mobileMenuOpen ? <X size={20}/> : <Menu size={20}/>}</button>

        <nav className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => {
            const active =
              location.pathname === item.to ||
              location.pathname.startsWith(`${item.to}/`);

            return (
              <Link
                key={item.to}
                to={item.to}
                className={`relative rounded-xl px-3 py-2 text-sm font-semibold transition-all ${
                  active
                    ? "bg-violet-50 text-violet-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-violet-600"
                }`}
              >
                {item.label}
                {active && (
                  <motion.span
                    layoutId="navbar-active"
                    className="absolute inset-x-3 -bottom-1 h-0.5 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-500"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex shrink-0 items-center gap-2 lg:ml-0">
          <button
            type="button"
            onClick={() => setDarkMode((current) => !current)}
            aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
            title={darkMode ? "Light mode" : "Dark mode"}
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 hover:border-violet-300 hover:text-violet-700"
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {!user ? (
            <div className="flex items-center gap-2">
              <Link to="/login">
                <Button
                  variant="outline"
                  className="rounded-xl border-slate-200 hover:border-violet-300 hover:bg-violet-50"
                >
                  Login
                </Button>
              </Link>
              <Link to="/signup">
                <Button className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 shadow-md shadow-violet-200 hover:-translate-y-0.5">
                  Signup
                </Button>
              </Link>
            </div>
          ) : (
            <Popover>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  aria-label="Open profile menu"
                  className="rounded-full outline-none ring-offset-2 transition hover:ring-2 hover:ring-violet-200"
                >
                  <Avatar className="h-11 w-11 border-2 border-white shadow-md">
                    <AvatarImage
                      src={user?.profile?.profilePhoto}
                      alt={user?.fullname || "Profile"}
                    />
                  </Avatar>
                </button>
              </PopoverTrigger>

              <PopoverContent
                align="end"
                className="w-80 rounded-2xl border-white/70 p-0 shadow-2xl shadow-violet-100"
              >
                <div className="rounded-t-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-500 p-5 text-white">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-14 w-14 border-2 border-white/70 shadow-lg">
                      <AvatarImage
                        src={user?.profile?.profilePhoto}
                        alt={user?.fullname || "Profile"}
                      />
                    </Avatar>
                    <div className="min-w-0">
                      <h4 className="truncate font-bold">{user?.fullname}</h4>
                      <p className="truncate text-xs text-violet-100">
                        {user?.email}
                      </p>
                      <span className="mt-1 inline-flex rounded-full bg-white/15 px-2 py-0.5 text-[11px] font-semibold capitalize">
                        {user?.role}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-1 p-3">
                  <Link
                    to={profileLink}
                    className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700"
                  >
                    <User2 size={18} /> View Profile
                  </Link>

                  {isAdmin && (
                    <Link
                      to="/admin/dashboard"
                      className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700"
                    >
                      <LayoutDashboard size={18} /> Admin Dashboard
                    </Link>
                  )}

                  {!isRecruiter && !isAdmin && (
                    <>
                      <Link to="/applications" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> Application tracking
                      </Link>
                      <Link to="/interviews" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> Notifications & calendar
                      </Link>
                      <Link to="/interview-preparation" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> Interview preparation
                      </Link>
                      <Link to="/assessments" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> My assessments
                      </Link>
                    </>
                  )}

                  {isRecruiter && (
                    <>
                      <Link to="/admin/hiring" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> Hiring pipeline & analytics
                      </Link>
                      <Link to="/admin/assignments" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <BriefcaseBusiness size={18} /> Manage assignments
                      </Link>
                      <Link to="/admin/companies" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-violet-50 hover:text-violet-700">
                        <LayoutDashboard size={18} /> Recruiter Dashboard
                      </Link>
                    </>
                  )}

                  <button
                    type="button"
                    onClick={logoutHandler}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-rose-600 hover:bg-rose-50"
                  >
                    <LogOut size={18} /> Logout
                  </button>
                </div>
              </PopoverContent>
            </Popover>
          )}
        </div>
      </div>
      {mobileMenuOpen && (
        <motion.nav initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="border-t border-slate-100 bg-white px-4 py-3 shadow-lg lg:hidden">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-2 sm:grid-cols-3">
            {navItems.map((item) => { const active = location.pathname === item.to || location.pathname.startsWith(`${item.to}/`); return <Link key={item.to} to={item.to} onClick={() => setMobileMenuOpen(false)} className={`rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active ? "bg-violet-100 text-violet-800" : "text-slate-600 hover:bg-violet-50 hover:text-violet-700"}`}>{item.label}</Link>; })}
          </div>
        </motion.nav>
      )}
    </motion.header>
  );
}
