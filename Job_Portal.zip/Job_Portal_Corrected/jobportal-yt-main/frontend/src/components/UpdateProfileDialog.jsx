import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Loader2 } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { USER_API_END_POINT } from "@/utils/constant";
import { setUser } from "@/redux/authSlice";
import { toast } from "sonner";

const readFileAsDataUrl = (file) =>
  new Promise((resolve, reject) => {
    if (!file) {
      resolve("");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read file."));
    reader.readAsDataURL(file);
  });

const UpdateProfileDialog = ({ open, setOpen }) => {
  const [loading, setLoading] = useState(false);
  const { user } = useSelector((store) => store.auth);
  const dispatch = useDispatch();

  const [input, setInput] = useState({
    fullname: user?.fullname || "",
    email: user?.email || "",
    phoneNumber: user?.phoneNumber || "",
    bio: user?.profile?.bio || "",
    skills: user?.profile?.skills?.join(", ") || "",
    resume: user?.profile?.resume || "",
    resumeOriginalName: user?.profile?.resumeOriginalName || "",
    profilePhoto: user?.profile?.profilePhoto || "",
  });
  useEffect(() => {
    if (!user) return;
    setInput({
      fullname: user.fullname || "",
      email: user.email || "",
      phoneNumber: user.phoneNumber || "",
      bio: user.profile?.bio || "",
      skills: user.profile?.skills?.join(", ") || "",
      resume: user.profile?.resume || "",
      resumeOriginalName: user.profile?.resumeOriginalName || "",
      profilePhoto: user.profile?.profilePhoto || "",
    });
  }, [user, open]);

  const changeEventHandler = (e) => {
    setInput((previous) => ({
      ...previous,
      [e.target.name]: e.target.value,
    }));
  };

  const resumeChangeHandler = async (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      toast.error("Resume must be smaller than 8MB.");
      return;
    }

    try {
      const resume = await readFileAsDataUrl(file);

      setInput((previous) => ({
        ...previous,
        resume,
        resumeOriginalName: file.name,
      }));
    } catch {
      toast.error("Unable to read resume.");
    }
  };

  const profilePhotoChangeHandler = async (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error("Profile image must be smaller than 2MB.");
      return;
    }

    try {
      const profilePhoto = await readFileAsDataUrl(file);

      setInput((previous) => ({
        ...previous,
        profilePhoto,
      }));
    } catch {
      toast.error("Unable to read profile image.");
    }
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const response = await axios.put(
        `${USER_API_END_POINT}/profile/update`,
        input,
        { withCredentials: true }
      );

      if (response.data.success) {
        dispatch(setUser(response.data.user));
        toast.success(response.data.message);
        setOpen(false);
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to update profile."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden rounded-3xl border-white/70 p-0 shadow-2xl shadow-violet-200/50 sm:max-w-[520px]">
        <DialogHeader className="bg-gradient-to-r from-violet-700 to-fuchsia-500 px-6 py-5 text-white">
          <DialogTitle className="text-xl text-white">Update Profile</DialogTitle>
        </DialogHeader>

        <form onSubmit={submitHandler}>
          <div className="grid gap-4 px-6 py-5">

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Name</Label>
              <Input
                name="fullname"
                value={input.fullname}
                onChange={changeEventHandler}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Email</Label>
              <Input
                name="email"
                type="email"
                value={input.email}
                onChange={changeEventHandler}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Phone</Label>
              <Input
                name="phoneNumber"
                value={input.phoneNumber}
                onChange={changeEventHandler}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Bio</Label>
              <Input
                name="bio"
                value={input.bio}
                onChange={changeEventHandler}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Skills</Label>
              <Input
                name="skills"
                value={input.skills}
                onChange={changeEventHandler}
                placeholder="React, Node.js, MongoDB"
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Photo</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={profilePhotoChangeHandler}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Resume</Label>
              <Input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={resumeChangeHandler}
                className="col-span-3"
              />
            </div>

          </div>

          <DialogFooter>
            <Button
              type="submit"
              disabled={loading}
              className="my-4 w-full rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 shadow-lg shadow-violet-200 hover:from-violet-700 hover:to-fuchsia-600"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Please wait
                </>
              ) : (
                "Update"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UpdateProfileDialog;
