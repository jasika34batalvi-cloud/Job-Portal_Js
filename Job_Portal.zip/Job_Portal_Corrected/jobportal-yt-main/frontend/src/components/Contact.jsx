import React, { useState } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Clock, MessageCircle, Send, ChevronDown, ShieldCheck } from "lucide-react";
import { useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "./shared/Navbar";
import Footer from "./shared/Footer";
import { CONTACT_API_END_POINT } from "@/utils/constant";

const faqs = [
 { q: "How do I apply for a job?", a: "Sign in, open Jobs, choose a suitable listing and select Apply. Track your application from the Applications page." },
 { q: "Can recruiters post job openings?", a: "Yes. Sign in with a recruiter account, complete your company profile and create job posts from the recruiter dashboard." },
 { q: "How can I track my application?", a: "Open Applications after signing in to see the latest status shared by the recruiter." },
 { q: "Who receives my contact message?", a: "Your message is securely saved in MongoDB and is visible to the Job Portal administrator in the Contact Messages dashboard." },
];
export default function Contact() {
 const { user, authChecked } = useSelector((state) => state.auth);
 const navigate = useNavigate();
 const [form, setForm] = useState({ subject: "", message: "" });
 const [sending, setSending] = useState(false);
 const [notice, setNotice] = useState({ type: "", text: "" });
 const [openFaq, setOpenFaq] = useState(0);
 const update = (e) => setForm((old) => ({ ...old, [e.target.name]: e.target.value }));
 const submit = async (e) => {
  e.preventDefault();
  if (!user) { navigate("/login", { state: { from: "/contact" } }); return; }
  setSending(true); setNotice({ type: "", text: "" });
  try {
   const { data } = await axios.post(`${CONTACT_API_END_POINT}`, form, { withCredentials: true });
   setNotice({ type: "success", text: data.message || "Your message has been sent successfully." });
   setForm({ subject: "", message: "" });
  } catch (error) { setNotice({ type: "error", text: error.response?.data?.message || "Unable to send your message. Please try again." }); }
  finally { setSending(false); }
 };
 return <div className="app-surface min-h-screen"><Navbar /><main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
  <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .55 }} className="mx-auto max-w-3xl text-center">
   <span className="inline-flex items-center gap-2 rounded-full bg-violet-100 px-4 py-2 text-xs font-extrabold uppercase tracking-[.18em] text-violet-700"><MessageCircle size={15}/> We are here to help</span>
   <h1 className="mt-5 text-4xl font-black tracking-tight text-slate-900 sm:text-5xl">Let's start a <span className="gradient-text">conversation.</span></h1>
   <p className="mt-4 leading-7 text-slate-600">Questions about jobs, applications or hiring? Send a message directly to our administrator.</p>
  </motion.div>
  <section className="mt-12 grid gap-7 lg:grid-cols-[.85fr_1.15fr]">
   <motion.aside initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: .12 }} className="premium-card rounded-3xl p-7">
    <h2 className="text-2xl font-extrabold text-slate-900">Contact information</h2><p className="mt-2 text-sm leading-6 text-slate-500">Our support team is ready to help with your job portal questions.</p>
    <div className="mt-7 space-y-6">
     {[[Mail,"Email","support@jobportal.com"],[Phone,"Phone","Contact support through the message form"],[MapPin,"Location","Online support for job seekers and recruiters"],[Clock,"Support hours","Monday – Saturday · 9:00 AM – 6:00 PM"]].map(([Icon,label,value])=><div key={label} className="flex items-center gap-4"><span className="rounded-xl bg-violet-100 p-3 text-violet-700"><Icon size={20}/></span><div><p className="font-bold text-slate-900">{label}</p><p className="text-sm text-slate-600">{value}</p></div></div>)}
    </div><div className="mt-8 rounded-2xl bg-violet-50 p-5"><div className="flex items-center gap-2 font-bold text-violet-800"><ShieldCheck size={19}/> Private and secure</div><p className="mt-2 text-sm leading-6 text-violet-700">Only administrators can view messages submitted through this form. Your account identity is attached automatically.</p></div>
   </motion.aside>
   <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .18 }} className="premium-card overflow-hidden rounded-3xl">
    <div className="border-b border-slate-100 p-7"><h2 className="text-2xl font-extrabold text-slate-900">Send us a message</h2><p className="mt-2 text-sm text-slate-500">{user ? "Your account details are attached automatically." : "Please login before sending a message."}</p></div>
    {user ? <form onSubmit={submit} className="space-y-5 p-7">
      <div className="grid gap-4 sm:grid-cols-2"><div className="rounded-xl bg-slate-50 p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-400">Sending as</p><p className="mt-1 font-bold text-slate-800">{user.fullname}</p></div><div className="rounded-xl bg-slate-50 p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-400">Account email</p><p className="mt-1 break-all font-bold text-slate-800">{user.email}</p></div></div>
      <label className="block text-sm font-semibold text-slate-700">Subject<input name="subject" value={form.subject} onChange={update} required minLength={3} maxLength={120} placeholder="How can we help?" className="field mt-2 w-full rounded-xl border px-4 py-3"/></label>
      <label className="block text-sm font-semibold text-slate-700">Message<textarea name="message" value={form.message} onChange={update} required minLength={10} maxLength={3000} rows={6} placeholder="Write your message here..." className="field mt-2 w-full resize-y rounded-xl border px-4 py-3"/></label>
      {notice.text && <p role="status" className={`rounded-xl px-4 py-3 text-sm ${notice.type === "success" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{notice.text}</p>}
      <button disabled={sending} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-700 to-fuchsia-600 px-5 py-3.5 font-bold text-white shadow-lg shadow-violet-200 transition duration-300 hover:-translate-y-1 hover:shadow-xl disabled:opacity-60">{sending ? "Sending..." : "Send message"}<Send size={17}/></button>
      <p className="text-xs leading-5 text-slate-400">Never include passwords, payment details or other sensitive information.</p>
     </form> : <div className="p-7"><div className="rounded-2xl border border-violet-100 bg-violet-50 p-6 text-center"><ShieldCheck className="mx-auto text-violet-700" size={34}/><h3 className="mt-3 text-lg font-extrabold text-slate-900">Login required</h3><p className="mt-2 text-sm text-slate-600">Sign in to your account before contacting the administrator. Your name and email will be filled in automatically.</p><Link to="/login" state={{ from: "/contact" }} className="mt-5 inline-flex rounded-xl bg-violet-700 px-6 py-3 font-bold text-white transition hover:-translate-y-0.5 hover:bg-violet-800">Login to continue</Link></div></div>}
   </motion.section>
  </section>
  <section className="mx-auto mt-16 max-w-4xl"><div className="text-center"><p className="text-xs font-black uppercase tracking-[.2em] text-violet-600">Quick answers</p><h2 className="mt-2 text-3xl font-black text-slate-900">Frequently asked questions</h2></div><div className="mt-7 space-y-3">{faqs.map((faq,index)=><motion.div layout key={faq.q} className="premium-card overflow-hidden rounded-2xl"><button type="button" onClick={()=>setOpenFaq(openFaq===index?-1:index)} aria-expanded={openFaq===index} className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left font-bold text-slate-900"><span>{faq.q}</span><ChevronDown className={`shrink-0 text-violet-600 transition-transform duration-300 ${openFaq===index?"rotate-180":""}`}/></button>{openFaq===index&&<motion.p initial={{opacity:0,y:-5}} animate={{opacity:1,y:0}} className="px-5 pb-5 text-sm leading-7 text-slate-600">{faq.a}</motion.p>}</motion.div>)}</div></section>
 </main><Footer/></div>;
}
