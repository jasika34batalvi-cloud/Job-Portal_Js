import React, { useMemo, useState } from "react";
import Navbar from "./shared/Navbar";
import { motion } from "framer-motion";
import { BrainCircuit, FileText, Sparkles, Target, UploadCloud } from "lucide-react";

const skillBank = ["javascript","react","node.js","node","express","mongodb","sql","python","java","html","css","tailwind","git","rest api","aws","communication","leadership","machine learning","data analysis","typescript","docker","figma"];
export default function ResumeAnalyzer() {
  const [resume, setResume] = useState("");
  const [job, setJob] = useState("React Developer");
  const [description, setDescription] = useState("React, JavaScript, HTML, CSS, REST API, Git, communication, Node.js and MongoDB");
  const [fileName, setFileName] = useState("");
  const [analyzed, setAnalyzed] = useState(false);
  const result = useMemo(() => {
    const text = `${resume} ${job} ${description}`.toLowerCase();
    const required = [...new Set(skillBank.filter(s => description.toLowerCase().includes(s)))];
    const found = required.filter(s => resume.toLowerCase().includes(s));
    const missing = required.filter(s => !resume.toLowerCase().includes(s));
    return { required, found, missing, score: required.length ? Math.round(found.length / required.length * 100) : 0 };
  }, [resume, description, job]);
  const upload = async e => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    if (file.type === "text/plain") setResume(await file.text());
    else setResume(prev => prev || `Resume file selected: ${file.name}. Paste the resume text below for skill analysis.`);
    setAnalyzed(false);
  };
  return <div className="min-h-screen app-surface"><Navbar/><main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
    <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} className="mb-8">
      <span className="inline-flex items-center gap-2 rounded-full bg-violet-100 px-4 py-2 text-sm font-bold text-violet-700"><Sparkles size={16}/> AI-powered career tool</span>
      <h1 className="mt-4 text-4xl font-black tracking-tight text-slate-900 sm:text-5xl">Resume <span className="gradient-text">Match Analyzer</span></h1>
      <p className="mt-3 max-w-2xl text-slate-600">Compare your resume with a target job, discover matching skills and identify what to improve before applying.</p>
    </motion.div>
    <div className="grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
      <section className="premium-card rounded-3xl p-6">
        <label className="mb-2 block text-sm font-bold text-slate-700">Target job title</label><input value={job} onChange={e=>{setJob(e.target.value);setAnalyzed(false)}} className="field mb-5 w-full rounded-xl border p-3" placeholder="e.g. Frontend Developer"/>
        <label className="mb-2 block text-sm font-bold text-slate-700">Job description / required skills</label><textarea value={description} onChange={e=>{setDescription(e.target.value);setAnalyzed(false)}} rows="4" className="field mb-5 w-full rounded-xl border p-3" placeholder="Paste job requirements..."/>
        <div className="mb-3 flex items-center justify-between"><label className="text-sm font-bold text-slate-700">Your resume content</label><label className="flex cursor-pointer items-center gap-2 text-sm font-semibold text-violet-700"><UploadCloud size={17}/> Upload TXT<input type="file" accept=".txt,text/plain" className="hidden" onChange={upload}/></label></div>
        {fileName && <p className="mb-2 text-xs text-slate-500"><FileText size={13} className="mr-1 inline"/>{fileName}</p>}
        <textarea value={resume} onChange={e=>{setResume(e.target.value);setAnalyzed(false)}} rows="9" className="field w-full rounded-xl border p-3" placeholder="Paste your resume text here (skills, experience, projects, education)..."/>
        <button onClick={()=>setAnalyzed(true)} disabled={!resume.trim() || !description.trim()} className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-700 to-fuchsia-600 px-5 py-3 font-bold text-white shadow-lg transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40"><BrainCircuit size={18}/> Analyze resume</button>
        <p className="mt-3 text-xs leading-5 text-slate-500">Privacy note: this demo performs keyword-based matching in your browser. It does not upload your resume to an external AI service. PDF/DOCX parsing can be connected as a future backend enhancement.</p>
      </section>
      <motion.aside initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} className="premium-card rounded-3xl p-6">
        <div className="flex items-center gap-3"><span className="rounded-2xl bg-violet-100 p-3 text-violet-700"><Target size={24}/></span><div><h2 className="text-xl font-extrabold text-slate-900">Match report</h2><p className="text-sm text-slate-500">{analyzed ? job : "Your results will appear here"}</p></div></div>
        {analyzed ? <><div className="my-7 text-center"><div className="mx-auto grid h-40 w-40 place-items-center rounded-full" style={{background:`conic-gradient(#7c3aed ${result.score*3.6}deg,#e9e5f5 0deg)`}}><div className="grid h-32 w-32 place-items-center rounded-full bg-white"><div><div className="text-4xl font-black text-slate-900">{result.score}%</div><div className="text-xs font-semibold text-slate-500">Skill match</div></div></div></div></div>
        <div className="grid grid-cols-2 gap-3"><div className="rounded-2xl bg-emerald-50 p-4"><p className="text-2xl font-black text-emerald-700">{result.found.length}</p><p className="text-xs font-bold text-emerald-800">Matched skills</p></div><div className="rounded-2xl bg-amber-50 p-4"><p className="text-2xl font-black text-amber-700">{result.missing.length}</p><p className="text-xs font-bold text-amber-800">Skills to improve</p></div></div>
        <h3 className="mb-2 mt-6 font-bold text-slate-800">Skills found</h3><div className="flex flex-wrap gap-2">{result.found.length ? result.found.map(s=><span key={s} className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800">{s}</span>) : <span className="text-sm text-slate-500">No matching skills found yet.</span>}</div>
        <h3 className="mb-2 mt-5 font-bold text-slate-800">Suggested improvements</h3><div className="flex flex-wrap gap-2">{result.missing.length ? result.missing.map(s=><span key={s} className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">Add evidence of {s}</span>) : <span className="text-sm text-emerald-700">Great! All detected requirements appear in your resume.</span>}</div>
        </> : <div className="mt-8 rounded-2xl border border-dashed border-violet-200 bg-violet-50/60 p-8 text-center"><BrainCircuit className="mx-auto mb-3 text-violet-500" size={38}/><p className="font-bold text-slate-800">Ready when you are</p><p className="mt-2 text-sm leading-6 text-slate-500">Add your resume and job requirements, then run the analysis to see a match score and skill gap report.</p></div>}
      </motion.aside>
    </div>
  </main></div>;
}
