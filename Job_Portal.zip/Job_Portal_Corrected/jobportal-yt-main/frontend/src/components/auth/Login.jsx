import React, { useEffect, useState } from "react";
import Navbar from "../shared/Navbar";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { RadioGroup } from "../ui/radio-group";
import { Button } from "../ui/button";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { USER_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { useDispatch, useSelector } from "react-redux";
import { setLoading, setUser } from "@/redux/authSlice";
import { Loader2, LogIn, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const Login = () => {
  const [input, setInput] = useState({ email: "", password: "", role: "" });
  const { loading, user } = useSelector((store) => store.auth);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const changeEventHandler = (e) =>
    setInput((previous) => ({ ...previous, [e.target.name]: e.target.value }));

  const submitHandler = async (e) => {
    e.preventDefault();

    if (!input.email || !input.password || !input.role) {
      toast.error("Email, password and role are required.");
      return;
    }

    try {
      dispatch(setLoading(true));
      const response = await axios.post(
        `${USER_API_END_POINT}/login`,
        input,
        { withCredentials: true }
      );

      if (response.data.success) {
        dispatch(setUser(response.data.user));
        toast.success(response.data.message);
        navigate(response.data.user.role === "recruiter" ? "/admin/companies" : "/");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Login failed. Please try again.");
    } finally {
      dispatch(setLoading(false));
    }
  };

  useEffect(() => {
    if (user) {
      navigate(user.role === "recruiter" ? "/admin/companies" : "/");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-orange-50">
      <Navbar />
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center px-4 py-10">
        <motion.form
          onSubmit={submitHandler}
          initial={{ opacity: 0, y: 30, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md rounded-2xl border border-white bg-white/90 p-7 shadow-2xl backdrop-blur"
        >
          <div className="mb-7 text-center">
            <motion.div
              initial={{ rotate: -10, scale: 0 }}
              animate={{ rotate: 0, scale: 1 }}
              transition={{ type: "spring", stiffness: 180 }}
              className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-purple-100 text-[#6A38C2]"
            >
              <LogIn />
            </motion.div>
            <h1 className="text-2xl font-bold">Welcome Back</h1>
            <p className="mt-1 text-sm text-gray-500">Login to continue your job search</p>
          </div>

          <div className="my-3">
            <Label>Email</Label>
            <Input type="email" value={input.email} name="email" onChange={changeEventHandler} placeholder="you@example.com" autoComplete="email" />
          </div>

          <div className="my-3">
            <Label>Password</Label>
            <Input type="password" value={input.password} name="password" onChange={changeEventHandler} placeholder="Enter password" autoComplete="current-password" />
          </div>

          <div className="my-4">
            <Label>Login as</Label>
            <RadioGroup className="mt-3 flex items-center gap-6">
              <label className="flex cursor-pointer items-center gap-2">
                <Input type="radio" name="role" value="student" checked={input.role === "student"} onChange={changeEventHandler} className="h-4 w-4 cursor-pointer" />
                <span>Student</span>
              </label>
              <label className="flex cursor-pointer items-center gap-2">
                <Input type="radio" name="role" value="recruiter" checked={input.role === "recruiter"} onChange={changeEventHandler} className="h-4 w-4 cursor-pointer" />
                <span>Recruiter</span>
              </label>
            </RadioGroup>
          </div>

          <Button type="submit" disabled={loading} className="my-4 w-full bg-[#6A38C2] py-6 hover:bg-[#5b30a6]">
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Please wait</> : <><Sparkles className="mr-2 h-4 w-4" />Login</>}
          </Button>

          <p className="text-center text-sm text-gray-600">
            Don't have an account?{" "}
            <Link to="/signup" className="font-semibold text-[#6A38C2] hover:underline">Signup</Link>
          </p>
        </motion.form>
      </div>
    </div>
  );
};

export default Login;
