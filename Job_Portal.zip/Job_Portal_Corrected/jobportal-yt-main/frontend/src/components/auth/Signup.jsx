import React, { useEffect, useState } from "react";
import Navbar from "../shared/Navbar";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { RadioGroup } from "../ui/radio-group";
import { Button } from "../ui/button";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { USER_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { useDispatch, useSelector } from "react-redux";
import { setLoading } from "@/redux/authSlice";
import { Loader2, UserPlus, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const readFileAsDataUrl = (file) =>
  new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read the image."));
    reader.readAsDataURL(file);
  });

const Signup = () => {
  const [input, setInput] = useState({
    fullname: "", email: "", phoneNumber: "", password: "", role: "", profilePhoto: "",
  });
  const { loading, user } = useSelector((store) => store.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const changeEventHandler = (e) =>
    setInput((previous) => ({ ...previous, [e.target.name]: e.target.value }));

  const changeFileHandler = async (e) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) {
        toast.error("Profile image must be smaller than 2MB.");
        return;
      }
      const profilePhoto = await readFileAsDataUrl(file);
      setInput((previous) => ({ ...previous, profilePhoto }));
    } catch {
      toast.error("Unable to read profile image.");
    }
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    if (!input.fullname || !input.email || !input.phoneNumber || !input.password || !input.role) {
      toast.error("Please fill all required fields.");
      return;
    }

    try {
      dispatch(setLoading(true));
      const response = await axios.post(`${USER_API_END_POINT}/register`, input, { withCredentials: true });
      if (response.data.success) {
        toast.success(response.data.message);
        navigate("/login");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Registration failed.");
    } finally {
      dispatch(setLoading(false));
    }
  };

  useEffect(() => {
    if (user) navigate(user.role === "recruiter" ? "/admin/companies" : "/");
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50">
      <Navbar />
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center px-4 py-10">
        <motion.form
          onSubmit={submitHandler}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-2xl rounded-2xl border border-white bg-white/90 p-7 shadow-2xl backdrop-blur"
        >
          <div className="mb-6 text-center">
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2.5, repeat: Infinity }}
              className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-orange-100 text-[#F83002]"
            >
              <UserPlus />
            </motion.div>
            <h1 className="text-2xl font-bold">Create Your Account</h1>
            <p className="mt-1 text-sm text-gray-500">Join JobPortal and discover your next opportunity</p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>Full Name</Label><Input type="text" value={input.fullname} name="fullname" onChange={changeEventHandler} placeholder="Your full name" /></div>
            <div><Label>Email</Label><Input type="email" value={input.email} name="email" onChange={changeEventHandler} placeholder="you@example.com" /></div>
            <div><Label>Phone Number</Label><Input type="tel" value={input.phoneNumber} name="phoneNumber" onChange={changeEventHandler} placeholder="9876543210" /></div>
            <div><Label>Password</Label><Input type="password" value={input.password} name="password" onChange={changeEventHandler} placeholder="Minimum 6 characters" /></div>
          </div>

          <div className="my-5 rounded-xl bg-gray-50 p-4">
            <Label>Account Type</Label>
            <RadioGroup className="mt-3 flex flex-wrap gap-6">
              <label className="flex cursor-pointer items-center gap-2"><Input type="radio" name="role" value="student" checked={input.role === "student"} onChange={changeEventHandler} className="h-4 w-4" /><span>Student</span></label>
              <label className="flex cursor-pointer items-center gap-2"><Input type="radio" name="role" value="recruiter" checked={input.role === "recruiter"} onChange={changeEventHandler} className="h-4 w-4" /><span>Recruiter</span></label>
            </RadioGroup>
          </div>

          <div className="my-4">
            <Label>Profile Photo (optional)</Label>
            <Input accept="image/*" type="file" onChange={changeFileHandler} className="mt-2 cursor-pointer" />
          </div>

          <Button type="submit" disabled={loading} className="my-4 w-full bg-[#6A38C2] py-6 hover:bg-[#5b30a6]">
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Please wait</> : <><Sparkles className="mr-2 h-4 w-4" />Create Account</>}
          </Button>

          <p className="text-center text-sm text-gray-600">
            Already have an account?{" "}
            <Link to="/login" className="font-semibold text-[#6A38C2] hover:underline">Login</Link>
          </p>
        </motion.form>
      </div>
    </div>
  );
};

export default Signup;
