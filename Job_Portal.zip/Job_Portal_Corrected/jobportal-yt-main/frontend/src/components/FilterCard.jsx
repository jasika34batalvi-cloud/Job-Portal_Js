import React from "react";
import { SlidersHorizontal, RotateCcw } from "lucide-react";

const SelectField = ({ label, value, onChange, options, placeholder = "All" }) => (
  <label className="block">
    <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span>
    <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 shadow-sm outline-none transition focus:border-violet-400 focus:ring-4 focus:ring-violet-100">
      <option value="">{placeholder}</option>
      {options.map((option) => <option key={option.value || option} value={option.value || option}>{option.label || option}</option>)}
    </select>
  </label>
);

const FilterCard = ({ filters, onChange, onClear, resultCount }) => {
  const set = (key, value) => onChange((current) => ({ ...current, [key]: value }));
  const activeCount = Object.values(filters).filter(Boolean).length;
  return (
    <aside className="animate-page-in h-fit rounded-2xl border border-slate-100 bg-white p-4 shadow-lg shadow-slate-200/50 sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2"><span className="rounded-xl bg-violet-100 p-2 text-violet-700"><SlidersHorizontal size={18}/></span><div><h2 className="font-extrabold text-slate-900">Filters</h2><p className="text-xs text-slate-500">{resultCount} jobs found</p></div></div>
        <button type="button" onClick={onClear} className="inline-flex items-center gap-1 text-xs font-bold text-violet-700 hover:text-fuchsia-700"><RotateCcw size={13}/> Clear all{activeCount ? ` (${activeCount})` : ""}</button>
      </div>
      <div className="mt-5 space-y-4">
        <SelectField label="Job type" value={filters.jobType} onChange={(v) => set("jobType", v)} options={["Full-time","Part-time","Internship","Contract","Freelance"]}/>
        <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">Location</span><input value={filters.location} onChange={(e) => set("location", e.target.value)} placeholder="City or state" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-4 focus:ring-violet-100"/></label>
        <SelectField label="Salary (LPA)" value={filters.salary} onChange={(v) => set("salary", v)} options={[{value:"0-3",label:"Below 3 LPA"},{value:"3-5",label:"3–5 LPA"},{value:"5-10",label:"5–10 LPA"},{value:"10-15",label:"10–15 LPA"},{value:"15-25",label:"15–25 LPA"},{value:"25+",label:"Above 25 LPA"}]}/>
        <SelectField label="Experience" value={filters.experience} onChange={(v) => set("experience", v)} options={[{value:"0",label:"Fresher (0 years)"},{value:"1-2",label:"1–2 years"},{value:"3-5",label:"3–5 years"},{value:"5+",label:"5+ years"}]}/>
        <SelectField label="Job category" value={filters.category} onChange={(v) => set("category", v)} options={["Frontend Developer","Backend Developer","Full Stack Developer","Software Engineer","Data Analyst","Data Scientist","UI/UX Designer","Java Developer","AI/ML Engineer","DevOps Engineer"]}/>
        <SelectField label="Date posted" value={filters.postedWithin} onChange={(v) => set("postedWithin", v)} options={[{value:"1",label:"Last 24 hours"},{value:"3",label:"Last 3 days"},{value:"7",label:"Last 7 days"},{value:"30",label:"Last 30 days"}]}/>
        <SelectField label="Work mode" value={filters.workMode} onChange={(v) => set("workMode", v)} options={["Remote","Hybrid","On-site"]}/>
        <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">Company</span><input value={filters.company} onChange={(e) => set("company", e.target.value)} placeholder="Company name" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-4 focus:ring-violet-100"/></label>
        <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">Skills</span><input value={filters.skills} onChange={(e) => set("skills", e.target.value)} placeholder="e.g. React, MongoDB" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-4 focus:ring-violet-100"/></label>
        <SelectField label="Sort by" value={filters.sort} onChange={(v) => set("sort", v)} options={[{value:"newest",label:"Newest first"},{value:"oldest",label:"Oldest first"},{value:"salaryHigh",label:"Salary: high to low"},{value:"salaryLow",label:"Salary: low to high"}]}/>
      </div>
    </aside>
  );
};
export default FilterCard;
