import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { BriefcaseBusiness, CheckCircle2, Clock3, XCircle, ArrowRight, Activity, RefreshCw } from "lucide-react";
import Navbar from "./shared/Navbar";
import useGetAppliedJobs from "@/hooks/useGetAppliedJobs";

const PIPELINE = ["Applied", "Shortlisted", "Assessment", "Interview", "Offer", "Hired", "Rejected"];

const ApplicationTracking = () => {
  useGetAppliedJobs();
  const { allAppliedJobs = [] } = useSelector((state) => state.job);

  const rejected = (application) =>
    application.pipelineStage === "Rejected" || application.status === "rejected";
  const completed = (application) =>
    application.pipelineStage === "Hired" || application.pipelineStage === "Offer" || application.status === "accepted";

  const counts = {
    total: allAppliedJobs.length,
    inProgress: allAppliedJobs.filter((a) => !rejected(a) && !completed(a)).length,
    shortlisted: allAppliedJobs.filter((a) => ["Shortlisted", "Assessment", "Interview", "Offer", "Hired"].includes(a.pipelineStage)).length,
    rejected: allAppliedJobs.filter(rejected).length,
  };

  const getStage = (application) => {
    if (application.pipelineStage) return application.pipelineStage;
    if (application.status === "accepted") return "Shortlisted";
    if (application.status === "rejected") return "Rejected";
    return "Applied";
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="mb-8">
          <div className="mb-2 flex items-center gap-2 text-sm font-bold text-violet-600"><Activity size={17}/> CAREER DASHBOARD</div>
          <h1 className="text-3xl font-extrabold text-slate-900">Application tracking</h1>
          <p className="mt-2 text-slate-500">Track every application from submission to the recruiter's final decision.</p>
        </div>

        <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { label: "Total applications", value: counts.total, icon: BriefcaseBusiness },
            { label: "In progress", value: counts.inProgress, icon: Clock3 },
            { label: "Shortlisted", value: counts.shortlisted, icon: CheckCircle2 },
            { label: "Not selected", value: counts.rejected, icon: XCircle },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between"><p className="text-sm text-slate-500">{label}</p><Icon className="text-violet-600" size={20}/></div>
              <p className="mt-2 text-3xl font-extrabold text-slate-900">{value}</p>
            </div>
          ))}
        </div>

        {!allAppliedJobs.length ? (
          <div className="rounded-3xl border border-dashed border-violet-200 bg-white p-12 text-center">
            <BriefcaseBusiness className="mx-auto text-violet-500" size={38}/>
            <h2 className="mt-4 text-xl font-bold">No applications to track yet</h2>
            <p className="mt-2 text-slate-500">Explore current openings and apply to start tracking your progress.</p>
            <Link to="/jobs" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-3 font-semibold text-white">Browse jobs <ArrowRight size={17}/></Link>
          </div>
        ) : (
          <div className="space-y-4">
            {allAppliedJobs.map((application) => {
              const stage = getStage(application);
              const isRejected = stage === "Rejected";
              const isHired = stage === "Hired";
              const activeIndex = PIPELINE.indexOf(stage);
              return (
                <article key={application._id} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
                  <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Applied {application.createdAt ? new Date(application.createdAt).toLocaleDateString() : "—"}</p>
                      <h2 className="mt-2 text-lg font-bold text-slate-900">{application.job?.title || "Job listing"}</h2>
                      <p className="mt-1 text-sm text-slate-500">{application.job?.company?.name || "Company not available"}</p>
                    </div>
                    <span className={`inline-flex w-fit items-center gap-2 rounded-full px-3 py-2 text-sm font-bold ${isRejected ? "bg-rose-50 text-rose-700" : isHired ? "bg-emerald-50 text-emerald-700" : "bg-violet-50 text-violet-700"}`}>
                      {isRejected ? <XCircle size={16}/> : isHired ? <CheckCircle2 size={16}/> : <Clock3 size={16}/>}
                      {stage}
                    </span>
                  </div>

                  <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-7">
                    {PIPELINE.map((item, index) => {
                      const active = isRejected ? item === "Applied" || item === "Rejected" : index <= activeIndex;
                      return (
                        <div key={item}>
                          <div className={`h-2 rounded-full ${active ? (isRejected && item === "Rejected" ? "bg-rose-500" : "bg-violet-600") : "bg-slate-100"}`}/>
                          <p className={`mt-2 text-xs ${active ? "font-bold text-slate-800" : "text-slate-400"}`}>{item}</p>
                        </div>
                      );
                    })}
                  </div>
                  <p className="mt-4 text-sm text-slate-500">Your recruiter updates this stage. New updates are also available in your notifications.</p>
                </article>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};

export default ApplicationTracking;
