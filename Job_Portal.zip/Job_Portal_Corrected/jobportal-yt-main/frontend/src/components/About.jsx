import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import Navbar from "./shared/Navbar";
import Footer from "./shared/Footer";
import { BriefcaseBusiness, Target, Users, ShieldCheck, Sparkles, ArrowRight } from "lucide-react";

const values = [
  { icon: Target, title: "Purpose-driven matching", text: "Help candidates discover roles that fit their skills, goals and experience." },
  { icon: Users, title: "People-first hiring", text: "Give job seekers and recruiters a clear, organized space to connect." },
  { icon: ShieldCheck, title: "A more transparent journey", text: "Make job discovery, applications and interview progress easier to follow." },
];

export default function About() {
  return <div className="app-surface min-h-screen"><Navbar />
    <main className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
      <motion.section initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} className="overflow-hidden rounded-[2rem] bg-gradient-to-br from-violet-900 via-violet-700 to-fuchsia-600 px-7 py-14 text-white shadow-2xl sm:px-14">
        <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-xs font-bold uppercase tracking-[.18em]"><BriefcaseBusiness size={15}/> About our platform</span>
        <h1 className="mt-6 max-w-3xl text-4xl font-black leading-tight sm:text-6xl">A smarter path from <span className="text-fuchsia-200">ambition</span> to opportunity.</h1>
        <p className="mt-5 max-w-2xl text-base leading-8 text-violet-100 sm:text-lg">Job Portal brings candidates and recruiters together through job discovery, profile tools, resume matching and a more organized hiring experience.</p>
        <Link to="/jobs" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-bold text-violet-800 hover:-translate-y-0.5">Explore jobs <ArrowRight size={17}/></Link>
      </motion.section>
      <section className="grid gap-8 py-16 lg:grid-cols-[1.1fr_.9fr] lg:items-center">
        <div><p className="text-xs font-black uppercase tracking-[.2em] text-violet-600">Who we are</p><h2 className="mt-3 text-3xl font-black text-slate-900 sm:text-4xl">Making every career step feel simpler.</h2><p className="mt-5 leading-8 text-slate-600">Our platform is designed to support the complete job-search journey. Candidates can explore opportunities, build their profiles, analyze resume alignment and track applications. Recruiters can manage job listings, review applicants and coordinate interviews from one workspace.</p><p className="mt-4 leading-8 text-slate-600">Our goal is to make hiring more accessible, organized and focused on meaningful connections.</p></div>
        <div className="premium-card rounded-3xl p-8"><Sparkles className="text-violet-600" size={30}/><h3 className="mt-4 text-2xl font-extrabold text-slate-900">One platform. Two journeys.</h3><div className="mt-6 grid grid-cols-2 gap-4"><div className="rounded-2xl bg-violet-50 p-5"><p className="font-bold text-violet-800">For candidates</p><p className="mt-2 text-sm leading-6 text-slate-600">Discover jobs, apply and track progress.</p></div><div className="rounded-2xl bg-fuchsia-50 p-5"><p className="font-bold text-fuchsia-800">For recruiters</p><p className="mt-2 text-sm leading-6 text-slate-600">Post roles and manage candidates.</p></div></div></div>
      </section>
      <section className="pb-10"><div className="mb-7"><p className="text-xs font-black uppercase tracking-[.2em] text-violet-600">What guides us</p><h2 className="mt-2 text-3xl font-black text-slate-900">Our values</h2></div><div className="grid gap-5 md:grid-cols-3">{values.map(({icon:Icon,title,text})=><article key={title} className="premium-card rounded-3xl p-7"><span className="inline-flex rounded-2xl bg-violet-100 p-3 text-violet-700"><Icon size={23}/></span><h3 className="mt-5 text-xl font-extrabold text-slate-900">{title}</h3><p className="mt-2 leading-7 text-slate-600">{text}</p></article>)}</div></section>
    </main><Footer/></div>;
}
