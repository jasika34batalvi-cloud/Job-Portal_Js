import React, { useEffect } from "react";
import Navbar from "./shared/Navbar";
import HeroSection from "./HeroSection";
import CategoryCarousel from "./CategoryCarousel";
import LatestJobs from "./LatestJobs";
import Footer from "./shared/Footer";
import useGetAllJobs from "@/hooks/useGetAllJobs";
import { useSelector } from "react-redux";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  BrainCircuit,
  ShieldCheck,
  CalendarCheck,
  BarChart3,
  ArrowRight,
  Sparkles,
} from "lucide-react";

const features = [
  {
    icon: BrainCircuit,
    title: "Smart resume matching",
    text: "Understand your skill fit and discover what to improve before applying.",
    color: "bg-violet-100 text-violet-700",
  },
  {
    icon: ShieldCheck,
    title: "Trusted opportunities",
    text: "A safer hiring experience with company verification and job review workflows.",
    color: "bg-emerald-100 text-emerald-700",
  },
  {
    icon: CalendarCheck,
    title: "Interview ready",
    text: "Keep your hiring journey organized with interview and application tracking.",
    color: "bg-orange-100 text-orange-700",
  },
  {
    icon: BarChart3,
    title: "Career insights",
    text: "Track your progress with clear application and recruitment insights.",
    color: "bg-sky-100 text-sky-700",
  },
];

export default function Home() {
  useGetAllJobs();

  const { user } = useSelector((store) => store.auth);
  const navigate = useNavigate();

  useEffect(() => {
    if (user?.role === "recruiter") {
      navigate("/admin/companies", { replace: true });
    } else if (user?.role === "admin") {
      navigate("/admin/dashboard", { replace: true });
    }
  }, [user, navigate]);

  return (
    <div className="app-surface min-h-screen overflow-hidden">
      <Navbar />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.55 }}
      >
        <HeroSection />
      </motion.div>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"
        >
          <div>
            <span className="text-xs font-extrabold uppercase tracking-[.22em] text-violet-600">
              A smarter way to get hired
            </span>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
              Everything you need to{" "}
              <span className="gradient-text">move forward</span>
            </h2>
            <p className="mt-2 max-w-2xl text-slate-500">
              Tools for candidates and recruiters, brought together in one
              simple workspace.
            </p>
          </div>

          <Link
            to="/resume-analyzer"
            className="inline-flex items-center gap-2 font-bold text-violet-700 transition-all hover:gap-3"
          >
            Try resume analyzer <ArrowRight size={17} />
          </Link>
        </motion.div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => {
            const Icon = feature.icon;

            return (
              <motion.article
                key={feature.title}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                whileHover={{ y: -7 }}
                className="premium-card rounded-3xl p-6"
              >
                <span
                  className={`mb-5 inline-flex rounded-2xl p-3 ${feature.color}`}
                >
                  <Icon size={23} />
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {feature.text}
                </p>
              </motion.article>
            );
          })}
        </div>
      </section>

      <motion.section
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mx-auto my-6 max-w-7xl px-4 sm:px-6"
      >
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-r from-violet-800 via-purple-700 to-fuchsia-600 p-8 text-white shadow-2xl sm:p-12">
          <div className="absolute -right-10 -top-24 h-72 w-72 rounded-full border-[35px] border-white/10" />
          <div className="relative max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1.5 text-xs font-bold">
              <Sparkles size={14} /> YOUR NEXT CHAPTER STARTS HERE
            </span>
            <h2 className="mt-4 text-3xl font-black sm:text-4xl">
              Make every application count.
            </h2>
            <p className="mt-3 leading-7 text-violet-100">
              Build a stronger profile, find roles that fit your skills and
              stay in control of your career journey.
            </p>
            <Link
              to="/resume-analyzer"
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-bold text-violet-800 shadow-lg transition hover:-translate-y-1"
            >
              Analyze my resume <ArrowRight size={17} />
            </Link>
          </div>
        </div>
      </motion.section>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.6 }}
      >
        <CategoryCarousel />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.7 }}
      >
        <LatestJobs />
      </motion.div>

      <Footer />
    </div>
  );
}
