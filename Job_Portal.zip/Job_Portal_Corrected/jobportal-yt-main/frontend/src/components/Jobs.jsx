import React, { useCallback, useEffect, useState } from "react";
import Navbar from "./shared/Navbar";
import FilterCard from "./FilterCard";
import Job from "./Job";
import { useSelector, useDispatch } from "react-redux";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import { JOB_API_END_POINT } from "@/utils/constant";
import { setAllJobs } from "@/redux/jobSlice";
import { Search, BriefcaseBusiness } from "lucide-react";

const EMPTY_FILTERS = { jobType:"", location:"", salary:"", experience:"", category:"", postedWithin:"", workMode:"", company:"", skills:"", sort:"newest" };
const Jobs = () => {
  const dispatch = useDispatch();
  const { allJobs, searchedQuery } = useSelector((store) => store.job);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [keyword, setKeyword] = useState(searchedQuery || "");
  const [filterJobs, setFilterJobs] = useState(allJobs || []);
  const [loading, setLoading] = useState(false);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = { ...filters, keyword: keyword.trim() };
      Object.keys(params).forEach((key) => { if (!params[key]) delete params[key]; });
      const response = await axios.get(`${JOB_API_END_POINT}/get`, { params, withCredentials:true });
      if (response.data.success) {
        dispatch(setAllJobs(response.data.jobs || []));
        setFilterJobs(response.data.jobs || []);
      }
    } catch (error) {
      console.error("JOB FILTER ERROR:", error);
      // Keep the already loaded jobs visible if the API request fails.
      setFilterJobs(allJobs || []);
    } finally { setLoading(false); }
  }, [filters, keyword, dispatch]);

  useEffect(() => { const timer = setTimeout(fetchJobs, 250); return () => clearTimeout(timer); }, [fetchJobs]);
  useEffect(() => { setKeyword(searchedQuery || ""); }, [searchedQuery]);

  const clearFilters = () => { setFilters(EMPTY_FILTERS); setKeyword(""); };
  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar/>
      <main className="mx-auto max-w-7xl px-4 py-7 sm:px-6 lg:px-8">
        <section className="mb-6 overflow-hidden rounded-3xl bg-gradient-to-r from-violet-700 via-purple-700 to-fuchsia-600 p-6 text-white shadow-xl shadow-violet-200/60 sm:p-8">
          <p className="text-sm font-semibold text-violet-100">Explore opportunities</p>
          <h1 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">Find your next career move</h1>
          <p className="mt-2 max-w-2xl text-sm text-violet-100">Discover roles that match your skills, experience and ambitions.</p>
          <div className="mt-5 flex max-w-2xl items-center gap-2 rounded-2xl bg-white p-2 shadow-lg">
            <Search className="ml-2 shrink-0 text-violet-500" size={19}/>
            <input value={keyword} onChange={(e)=>setKeyword(e.target.value)} placeholder="Search job title, skills or keywords..." className="min-w-0 flex-1 border-0 bg-transparent px-1 py-2 text-sm text-slate-800 outline-none ring-0 placeholder:text-slate-400 focus:ring-0"/>
            <button onClick={fetchJobs} className="rounded-xl bg-violet-700 px-4 py-2.5 text-sm font-bold text-white hover:bg-violet-800">Search</button>
          </div>
        </section>
        <div className="grid items-start gap-6 lg:grid-cols-[290px_minmax(0,1fr)]">
          <FilterCard filters={filters} onChange={setFilters} onClear={clearFilters} resultCount={filterJobs.length}/>
          <section className="min-w-0">
            <div className="mb-4 flex items-center justify-between"><div><h2 className="text-xl font-extrabold text-slate-900">Available jobs</h2><p className="text-sm text-slate-500">{filterJobs.length} matching opportunities</p></div><span className="rounded-full bg-violet-100 px-3 py-1 text-xs font-bold text-violet-700">{loading ? "Updating…" : "Live results"}</span></div>
            {loading && filterJobs.length === 0 ? <div className="rounded-2xl bg-white p-12 text-center text-slate-500">Finding matching jobs…</div> : filterJobs.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center"><BriefcaseBusiness className="mx-auto text-violet-400" size={38}/><h3 className="mt-3 font-bold text-slate-900">No jobs match these filters</h3><p className="mt-1 text-sm text-slate-500">Try changing your search or clearing some filters.</p><button onClick={clearFilters} className="mt-4 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-violet-700">Clear all filters</button></div> : <motion.div layout className="grid gap-4 sm:grid-cols-2 xl:grid-cols-2"><AnimatePresence mode="popLayout">{filterJobs.map((job) => <motion.div layout key={job._id} initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} exit={{opacity:0,scale:.96}} transition={{duration:.22}}><Job job={job}/></motion.div>)}</AnimatePresence></motion.div>}
          </section>
        </div>
      </main>
    </div>
  );
};
export default Jobs;
