import React, { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import Navbar from "../shared/Navbar";
import { CAREER_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { BarChart3, Users, BriefcaseBusiness, UserCheck, ClipboardList, RefreshCw, Trash2 } from "lucide-react";

const STAGES = ["Applied", "Shortlisted", "Assessment", "Interview", "Offer", "Hired", "Rejected"];
const emptyAnalytics = { totalJobs: 0, totalCandidates: 0, newThisMonth: 0, interviews: 0, hired: 0, rejected: 0, hireRate: 0, assessmentsAssigned: 0, assessmentsSubmitted: 0, stages: {} };

const HiringManagement = ({ mode = "hiring" }) => {
  const [candidates, setCandidates] = useState([]);
  const [analytics, setAnalytics] = useState(emptyAnalytics);
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState("All");
  const [jobFilter, setJobFilter] = useState("All");
  const [selected, setSelected] = useState("");
  const [note, setNote] = useState("");
  const [rating, setRating] = useState("5");
  const [feedback, setFeedback] = useState("");
  const [assessmentTitle, setAssessmentTitle] = useState("");
  const [instructions, setInstructions] = useState("");
  const [dueAt, setDueAt] = useState("");
  const [reviewValues, setReviewValues] = useState({});

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [candidateRes, analyticsRes, assessmentRes] = await Promise.all([
        axios.get(`${CAREER_API_END_POINT}/candidates`, { withCredentials: true }),
        axios.get(`${CAREER_API_END_POINT}/hiring/analytics`, { withCredentials: true }),
        axios.get(`${CAREER_API_END_POINT}/assessments`, { withCredentials: true }),
      ]);
      setCandidates(candidateRes.data.candidates || []);
      setAnalytics(analyticsRes.data.analytics || emptyAnalytics);
      setAssessments(assessmentRes.data.assessments || []);
    } catch (error) {
      toast.error(error.response?.data?.message || "Unable to load hiring workspace.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const jobOptions = useMemo(() => [...new Map(candidates.map((c) => [c.jobId, { id: c.jobId, title: c.jobTitle }])).values()], [candidates]);
  const filtered = useMemo(() => candidates.filter((c) => {
    const haystack = `${c.studentName} ${c.studentEmail} ${c.studentPhone || ""} ${c.jobTitle} ${c.company} ${(c.studentSkills || []).join(" ")}`.toLowerCase();
    return haystack.includes(search.toLowerCase())
      && (stageFilter === "All" || (c.pipelineStage || "Applied") === stageFilter)
      && (jobFilter === "All" || c.jobId === jobFilter);
  }), [candidates, search, stageFilter, jobFilter]);
  const activeCandidate = candidates.find((c) => c.applicationId === selected);

  const changeStage = async (candidate, stage) => {
    try {
      await axios.patch(`${CAREER_API_END_POINT}/hiring/applications/${candidate.applicationId}/stage`, { stage }, { withCredentials: true });
      toast.success(`Moved ${candidate.studentName} to ${stage}.`);
      await loadData();
    } catch (error) { toast.error(error.response?.data?.message || "Could not update stage."); }
  };

  const saveNote = async (event) => {
    event.preventDefault();
    if (!selected || !note.trim()) return toast.error("Select a candidate and enter a note.");
    try {
      await axios.post(`${CAREER_API_END_POINT}/hiring/applications/${selected}/notes`, { text: note }, { withCredentials: true });
      toast.success("Private candidate note saved.");
      setNote(""); await loadData();
    } catch (error) { toast.error(error.response?.data?.message || "Could not save note."); }
  };

  const saveFeedback = async (event) => {
    event.preventDefault();
    if (!selected) return toast.error("Select a candidate first.");
    try {
      await axios.post(`${CAREER_API_END_POINT}/hiring/applications/${selected}/feedback`, { rating: Number(rating), comments: feedback }, { withCredentials: true });
      toast.success("Interview feedback saved.");
      setFeedback(""); await loadData();
    } catch (error) { toast.error(error.response?.data?.message || "Could not save feedback."); }
  };

  const createAssessment = async (event) => {
    event.preventDefault();

    if (!selected || !assessmentTitle.trim() || !instructions.trim()) {
      toast.error("Select a candidate and complete the assignment fields.");
      return;
    }

    try {
      setSending(true);

      const response = await axios.post(
        `${CAREER_API_END_POINT}/assessments`,
        {
          applicationId: selected,
          title: assessmentTitle.trim(),
          instructions: instructions.trim(),
          dueAt: dueAt || null,
        },
        { withCredentials: true }
      );

      if (response.data?.success) {
        toast.success("Assignments sent successfully!");
        setSelected("");
        setAssessmentTitle("");
        setInstructions("");
        setDueAt("");
        await loadData();
      } else {
        toast.error(response.data?.message || "Could not assign assessment.");
      }
    } catch (error) {
      console.error("CREATE ASSESSMENT ERROR:", error);
      toast.error(
        error.response?.data?.message || "Could not assign assessment."
      );
    } finally {
      setSending(false);
    }
  };

  const deleteAssessment = async (assessment) => {
    const confirmed = window.confirm(`Delete the assessment "${assessment.title}"? This action cannot be undone.`);
    if (!confirmed) return;
    try {
      await axios.delete(`${CAREER_API_END_POINT}/assessments/${assessment._id}`, { withCredentials: true });
      toast.success("Assessment deleted successfully.");
      setAssessments((current) => current.filter((item) => item._id !== assessment._id));
    } catch (error) {
      toast.error(error.response?.data?.message || "Unable to delete assessment.");
    }
  };

  const reviewAssessment = async (assessment) => {
    const values = reviewValues[assessment._id] || {};
    try {
      await axios.patch(`${CAREER_API_END_POINT}/assessments/${assessment._id}/review`, {
        score: Number(values.score), reviewerFeedback: values.feedback || "",
      }, { withCredentials: true });
      toast.success("Assessment result saved.");
      await loadData();
    } catch (error) { toast.error(error.response?.data?.message || "Could not review assessment."); }
  };

  const statCards = [
    { label: "Candidates", value: analytics.totalCandidates, detail: `${analytics.newThisMonth} new this month`, icon: Users },
    { label: "Open job posts", value: analytics.totalJobs, detail: "Your active job inventory", icon: BriefcaseBusiness },
    { label: "Interviews", value: analytics.interviews, detail: "Currently in interview stage", icon: ClipboardList },
    { label: "Hired", value: analytics.hired, detail: `${analytics.hireRate}% candidate-to-hire rate`, icon: UserCheck },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <main className="mx-auto max-w-7xl space-y-7 px-4 py-8 sm:px-6">
        <section className="flex flex-col justify-between gap-4 rounded-3xl bg-gradient-to-r from-violet-700 via-purple-700 to-fuchsia-600 p-6 text-white shadow-xl shadow-violet-200 sm:flex-row sm:items-center sm:p-8">
          <div>
            <p className="text-sm font-semibold text-violet-100">Recruiter workspace</p>
            <h1 className="mt-1 text-3xl font-black tracking-tight">{mode === "hiring" ? "Hiring pipeline & analytics" : "Assignments"}</h1>
            <p className="mt-2 max-w-2xl text-sm text-violet-100">{mode === "hiring" ? "Manage candidates, hiring stages, private notes and interview feedback." : "Send assignments to candidates, track submissions and review student work."}</p>
          </div>
          <button onClick={loadData} className="inline-flex items-center justify-center gap-2 self-start rounded-xl bg-white/15 px-4 py-3 text-sm font-bold hover:bg-white/25 sm:self-center"><RefreshCw size={16}/> Refresh data</button>
        </section>

        {mode === "hiring" && <>
        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {statCards.map(({ label, value, detail, icon: Icon }) => (
            <div key={label} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between"><span className="text-sm font-semibold text-slate-500">{label}</span><span className="rounded-xl bg-violet-50 p-2 text-violet-700"><Icon size={19}/></span></div>
              <div className="mt-3 text-3xl font-black text-slate-900">{value}</div><p className="mt-1 text-xs text-slate-500">{detail}</p>
            </div>
          ))}
        </section>
        </>}

        {mode === "hiring" && <>
        <section className="grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
            <div className="mb-5 flex items-center gap-2"><BarChart3 className="text-violet-600"/><div><h2 className="text-lg font-extrabold text-slate-900">Pipeline overview</h2><p className="text-sm text-slate-500">Candidate count at each stage</p></div></div>
            <div className="space-y-4">
              {STAGES.map((stage) => {
                const count = analytics.stages?.[stage] || 0;
                const percent = analytics.totalCandidates ? Math.round(count / analytics.totalCandidates * 100) : 0;
                return <div key={stage}><div className="mb-1.5 flex justify-between text-sm"><span className="font-semibold text-slate-700">{stage}</span><span className="text-slate-500">{count} · {percent}%</span></div><div className="h-2.5 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-500 transition-all" style={{ width: `${percent}%` }}/></div></div>;
              })}
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3 border-t border-slate-100 pt-4 text-sm"><p className="text-slate-500">Assessments assigned <strong className="float-right text-slate-900">{analytics.assessmentsAssigned}</strong></p><p className="text-slate-500">Submitted/reviewed <strong className="float-right text-slate-900">{analytics.assessmentsSubmitted}</strong></p></div>
          </div>

          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
            <div className="mb-5 flex items-center gap-2"><BarChart3 className="text-violet-600"/><div><h2 className="text-lg font-extrabold text-slate-900">Recruitment activity</h2><p className="text-sm text-slate-500">Applications received over the last six months</p></div></div>
            <div className="flex h-44 items-end justify-between gap-3 border-b border-slate-100 pb-2">
              {(analytics.monthlyApplications || []).map((item) => {
                const maximum = Math.max(1, ...(analytics.monthlyApplications || []).map((month) => month.applications));
                const height = Math.max(5, Math.round((item.applications / maximum) * 100));
                return <div key={item.month} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
                  <span className="text-xs font-bold text-slate-600">{item.applications}</span>
                  <div className="w-full max-w-10 rounded-t-lg bg-gradient-to-t from-violet-700 to-fuchsia-500" style={{ height: `${height}%` }} />
                  <span className="text-xs text-slate-500">{item.month}</span>
                </div>;
              })}
              {(!analytics.monthlyApplications || analytics.monthlyApplications.length === 0) && <p className="m-auto text-sm text-slate-400">No monthly data available yet.</p>}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <p className="text-slate-500">Shortlisted <strong className="float-right text-slate-900">{analytics.shortlisted || 0}</strong></p>
              <p className="text-slate-500">Rejected <strong className="float-right text-slate-900">{analytics.rejected || 0}</strong></p>
              <p className="text-slate-500">Average assessment score <strong className="float-right text-slate-900">{analytics.averageAssessmentScore || 0}/100</strong></p>
              <p className="text-slate-500">Hire rate <strong className="float-right text-slate-900">{analytics.hireRate || 0}%</strong></p>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
            <h2 className="text-lg font-extrabold text-slate-900">Candidate notes & interview feedback</h2>
            <p className="mb-4 mt-1 text-sm text-slate-500">Select a candidate to record private recruiter notes and structured interview feedback.</p>
            <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">Candidate</label>
            <select value={selected} onChange={(e) => setSelected(e.target.value)} className="mb-4 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm outline-none focus:border-violet-400">
              <option value="">Choose a candidate…</option>
              {candidates.map((c) => <option key={c.applicationId} value={c.applicationId}>{c.studentName} — {c.jobTitle}</option>)}
            </select>
            {activeCandidate && <div className="mb-4 rounded-xl bg-violet-50 p-3 text-sm"><strong className="text-violet-900">{activeCandidate.studentName}</strong><p className="text-violet-700">{activeCandidate.studentEmail} · {activeCandidate.jobTitle}</p><p className="mt-2 font-semibold text-violet-800">Notes saved: {activeCandidate.candidateNotes?.length || 0} · Feedback entries: {activeCandidate.interviewFeedback?.length || 0}</p>{activeCandidate.candidateNotes?.length > 0 && <div className="mt-3 space-y-2"><p className="text-xs font-bold uppercase tracking-wide text-violet-800">Saved private notes</p>{activeCandidate.candidateNotes.slice().reverse().map((item, index) => <p key={item._id || index} className="rounded-lg bg-white/80 p-2 text-slate-700">{item.text}<span className="mt-1 block text-[11px] text-slate-400">{item.createdAt ? new Date(item.createdAt).toLocaleString() : ""}</span></p>)}</div>}{activeCandidate.interviewFeedback?.length > 0 && <div className="mt-3 space-y-2"><p className="text-xs font-bold uppercase tracking-wide text-violet-800">Saved interview feedback</p>{activeCandidate.interviewFeedback.slice().reverse().map((item, index) => <p key={item._id || index} className="rounded-lg bg-white/80 p-2 text-slate-700"><strong>{item.rating}/5</strong>{item.comments ? ` — ${item.comments}` : ""}<span className="mt-1 block text-[11px] text-slate-400">{item.createdAt ? new Date(item.createdAt).toLocaleString() : ""}</span></p>)}</div>}</div>}
            <form onSubmit={saveNote} className="space-y-2 border-t border-slate-100 pt-4">
              <label className="block text-sm font-bold text-slate-700">Add private note</label>
              <textarea value={note} onChange={(e) => setNote(e.target.value)} maxLength={2000} rows={2} placeholder="Skills, concerns, follow-up items…" className="w-full rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-violet-400" />
              <button className="rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-violet-700">Save note</button>
            </form>
            <form onSubmit={saveFeedback} className="mt-5 space-y-2 border-t border-slate-100 pt-4">
              <label className="block text-sm font-bold text-slate-700">Interview feedback</label>
              <select value={rating} onChange={(e) => setRating(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm"><option value="5">5 — Excellent</option><option value="4">4 — Very good</option><option value="3">3 — Meets expectations</option><option value="2">2 — Needs improvement</option><option value="1">1 — Not suitable</option></select>
              <textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} maxLength={3000} rows={2} placeholder="Evidence-based feedback and next steps…" className="w-full rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-violet-400" />
              <button className="rounded-xl border border-violet-200 px-4 py-2.5 text-sm font-bold text-violet-700 hover:bg-violet-50">Save feedback</button>
            </form>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-4 flex flex-col gap-3">
            <div><h2 className="text-lg font-extrabold text-slate-900">Candidate management</h2><p className="text-sm text-slate-500">Search, filter, review candidate profiles and move applicants through the hiring pipeline.</p></div>
            <div className="grid gap-2 md:grid-cols-[1fr_190px_220px]">
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, email, phone, skills or job…" className="w-full rounded-xl border border-slate-200 p-3 text-sm"/>
              <select value={stageFilter} onChange={(e) => setStageFilter(e.target.value)} className="rounded-xl border border-slate-200 bg-white p-3 text-sm"><option value="All">All stages</option>{STAGES.map((stage) => <option key={stage} value={stage}>{stage}</option>)}</select>
              <select value={jobFilter} onChange={(e) => setJobFilter(e.target.value)} className="rounded-xl border border-slate-200 bg-white p-3 text-sm"><option value="All">All jobs</option>{jobOptions.map((job) => <option key={job.id} value={job.id}>{job.title}</option>)}</select>
            </div>
            <p className="text-xs font-semibold text-slate-500">Showing {filtered.length} of {candidates.length} candidates</p>
          </div>
          {loading ? <p className="py-8 text-center text-sm text-slate-500">Loading hiring data…</p> : filtered.length === 0 ? <p className="rounded-xl bg-slate-50 py-10 text-center text-sm text-slate-500">No candidates match these filters.</p> : <div className="overflow-x-auto"><table className="w-full min-w-[980px] text-left text-sm"><thead><tr className="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-500"><th className="p-3">Candidate</th><th className="p-3">Skills</th><th className="p-3">Job</th><th className="p-3">Applied</th><th className="p-3">Resume</th><th className="p-3">Stage</th><th className="p-3">Activity</th></tr></thead><tbody>{filtered.map((c) => <tr key={c.applicationId} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/70"><td className="p-3"><div className="font-bold text-slate-900">{c.studentName}</div><div className="text-xs text-slate-500">{c.studentEmail}</div><div className="text-xs text-slate-500">{c.studentPhone || "Phone not added"}</div></td><td className="p-3"><div className="flex max-w-52 flex-wrap gap-1">{(c.studentSkills || []).length ? c.studentSkills.slice(0, 5).map((skill) => <span key={skill} className="rounded-full bg-violet-50 px-2 py-1 text-[11px] font-semibold text-violet-700">{skill}</span>) : <span className="text-xs text-slate-400">No skills added</span>}</div></td><td className="p-3"><div className="font-semibold text-slate-700">{c.jobTitle}</div><div className="text-xs text-slate-500">{c.company}</div></td><td className="p-3 text-slate-500">{c.createdAt ? new Date(c.createdAt).toLocaleDateString() : "—"}</td><td className="p-3">{c.resume ? <a href={c.resume} target="_blank" rel="noreferrer" className="font-semibold text-violet-700 hover:underline">{c.resumeOriginalName || "View resume"}</a> : <span className="text-xs text-slate-400">Not uploaded</span>}</td><td className="p-3"><select value={c.pipelineStage || "Applied"} onChange={(e) => changeStage(c, e.target.value)} className="rounded-lg border border-slate-200 bg-white p-2 text-xs font-semibold"><option value="Applied">Applied</option>{STAGES.filter((stage) => stage !== "Applied").map((stage) => <option key={stage} value={stage}>{stage}</option>)}</select></td><td className="p-3 text-slate-600">{c.candidateNotes?.length || 0} notes · {c.interviewFeedback?.length || 0} reviews</td></tr>)}</tbody></table></div>}
        </section>
        </>}

        {mode === "assignments" && <>
        <section className="grid gap-6 lg:grid-cols-[.9fr_1.1fr]">
          <form onSubmit={createAssessment} className="space-y-3 rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
            <div><h2 className="text-lg font-extrabold text-slate-900">Send an assignment</h2><p className="text-sm text-slate-500">Send a task or take-home exercise directly to a selected student.</p></div>
            <label className="block text-xs font-bold uppercase tracking-wide text-slate-500">Candidate</label>
            <select value={selected} onChange={(e) => setSelected(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm" required><option value="">Choose a candidate…</option>{candidates.map((c) => <option key={c.applicationId} value={c.applicationId}>{c.studentName} — {c.jobTitle}</option>)}</select>
            <input value={assessmentTitle} onChange={(e) => setAssessmentTitle(e.target.value)} maxLength={120} required placeholder="Assignment title, e.g. React fundamentals" className="w-full rounded-xl border border-slate-200 p-3 text-sm"/>
            <textarea value={instructions} onChange={(e) => setInstructions(e.target.value)} maxLength={5000} required rows={4} placeholder="Instructions, requirements and submission expectations…" className="w-full rounded-xl border border-slate-200 p-3 text-sm"/>
            <div><label className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">Due date (optional)</label><input type="datetime-local" value={dueAt} onChange={(e) => setDueAt(e.target.value)} className="w-full rounded-xl border border-slate-200 p-3 text-sm"/></div>
            <button
              type="submit"
              disabled={sending}
              className="w-full rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 px-4 py-3 text-sm font-bold text-white shadow-md shadow-violet-100 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {sending ? "Sending..." : "Send assignment"}
            </button>
          </form>

          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6">
            <h2 className="text-lg font-extrabold text-slate-900">Assignment submissions</h2><p className="mb-4 text-sm text-slate-500">View student submissions and provide marks and feedback.</p>
            {assessments.length === 0 ? <p className="rounded-xl bg-slate-50 p-6 text-center text-sm text-slate-500">No assessments assigned yet.</p> : <div className="space-y-3">{assessments.map((a) => <article key={a._id} className="rounded-xl border border-slate-100 p-4"><div className="flex flex-wrap items-start justify-between gap-2"><div><h3 className="font-bold text-slate-900">{a.title}</h3><p className="text-xs text-slate-500">{a.application?.applicant?.fullname || "Candidate"} · {a.application?.job?.title || "Job"}</p></div><div className="flex items-center gap-2"><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${a.status === "reviewed" ? "bg-emerald-50 text-emerald-700" : a.status === "submitted" ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{a.status}</span><button type="button" onClick={() => deleteAssessment(a)} className="inline-flex items-center gap-1 rounded-lg border border-rose-100 px-2.5 py-1.5 text-xs font-bold text-rose-600 transition hover:border-rose-200 hover:bg-rose-50" title="Delete assessment"><Trash2 size={14}/> Delete</button></div></div><p className="mt-2 whitespace-pre-wrap text-sm text-slate-600">{a.instructions}</p>{a.status !== "assigned" && <div className="mt-3 rounded-lg bg-slate-50 p-3"><p className="mb-1 text-xs font-bold uppercase text-slate-500">Candidate response</p><p className="whitespace-pre-wrap text-sm text-slate-700">{a.response || "No response"}</p></div>}{a.status === "submitted" && <div className="mt-3 space-y-2"><input type="number" min="0" max="100" placeholder="Score / 100" value={reviewValues[a._id]?.score ?? ""} onChange={(e) => setReviewValues((prev) => ({ ...prev, [a._id]: { ...prev[a._id], score: e.target.value } }))} className="w-full rounded-lg border border-slate-200 p-2.5 text-sm"/><textarea rows={2} placeholder="Feedback for candidate (optional)" value={reviewValues[a._id]?.feedback ?? ""} onChange={(e) => setReviewValues((prev) => ({ ...prev, [a._id]: { ...prev[a._id], feedback: e.target.value } }))} className="w-full rounded-lg border border-slate-200 p-2.5 text-sm"/><button onClick={() => reviewAssessment(a)} className="rounded-lg bg-violet-600 px-3 py-2 text-xs font-bold text-white">Save score & feedback</button></div>}{a.status === "reviewed" && <p className="mt-3 text-sm font-bold text-emerald-700">Score: {a.score}/100 {a.reviewerFeedback ? `— ${a.reviewerFeedback}` : ""}</p>}</article>)}</div>}
          </div>
        </section>
        </>}
      </main>
    </div>
  );
};

export default HiringManagement;
