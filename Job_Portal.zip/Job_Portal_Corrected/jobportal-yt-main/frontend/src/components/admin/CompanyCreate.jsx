import React, { useState } from "react";
import Navbar from "../shared/Navbar";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { COMPANY_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { useDispatch } from "react-redux";
import { setSingleCompany } from "@/redux/companySlice";

const CompanyCreate = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [companyName, setCompanyName] = useState("");
  const [loading, setLoading] = useState(false);

  const registerNewCompany = async () => {
    if (!companyName.trim()) {
      toast.error("Company name is required.");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post(
        `${COMPANY_API_END_POINT}/register`,
        { companyName: companyName.trim() },
        { withCredentials: true }
      );

      if (response.data.success) {
        dispatch(setSingleCompany(response.data.company));
        toast.success(response.data.message);

        navigate(
          `/admin/companies/${response.data.company._id}`
        );
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to create company."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='min-h-screen'>
      <Navbar />

      <div className="mx-auto max-w-4xl px-4 py-10 animate-page-in">
        <div className="mb-8 rounded-3xl bg-gradient-to-r from-violet-700 to-fuchsia-500 p-8 text-white shadow-xl shadow-violet-200">
          <h1 className="font-bold text-2xl">
            Your Company Name
          </h1>

          <p className="text-violet-100">
            What would you like to give your company name?
            You can change this later.
          </p>
        </div>

        <Label>Company Name</Label>

        <Input
          type="text"
          className="my-2 rounded-xl bg-white"
          placeholder="JobHunt, Microsoft etc."
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
        />

        <div className="my-8 flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate("/admin/companies")}
          >
            Cancel
          </Button>

          <Button
            type="button"
            disabled={loading}
            onClick={registerNewCompany}
          >
            {loading ? "Creating..." : "Continue"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CompanyCreate;
