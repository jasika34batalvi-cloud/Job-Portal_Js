import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
export default function AdminOnlyRoute({ children }) {
  const { user, authChecked } = useSelector((state) => state.auth);
  if (!authChecked) return <div className="p-10 text-center">Checking administrator access…</div>;
  return user?.role === "admin" ? children : <Navigate to="/" replace />;
}
