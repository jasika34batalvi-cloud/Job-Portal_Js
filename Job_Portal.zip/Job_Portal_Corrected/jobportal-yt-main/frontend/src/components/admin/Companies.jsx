import React, { useEffect, useState } from 'react'
import Navbar from '../shared/Navbar'
import { Input } from '../ui/input'
import { Button } from '../ui/button'
import CompaniesTable from './CompaniesTable'
import { useNavigate } from 'react-router-dom'
import useGetAllCompanies from '@/hooks/useGetAllCompanies'
import { useDispatch } from 'react-redux'
import { setSearchCompanyByText } from '@/redux/companySlice'

const Companies = () => {
    useGetAllCompanies();
    const [input, setInput] = useState("");
    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(()=>{
        dispatch(setSearchCompanyByText(input));
    },[input]);
    return (
        <div className='min-h-screen'>
            <Navbar />
            <main className='mx-auto max-w-6xl px-4 py-8 sm:px-6 animate-page-in'>
                <div className='mb-7'>
                    <p className='text-sm font-semibold text-violet-600'>Recruiter workspace</p>
                    <h1 className='mt-1 text-3xl font-extrabold text-slate-900'>Your Companies</h1>
                    <p className='mt-1 text-slate-500'>Create and manage the companies you use for job postings.</p>
                </div>
                <div className='mb-5 flex flex-col gap-3 rounded-2xl border border-white bg-white p-4 shadow-lg shadow-slate-200/50 sm:flex-row sm:items-center sm:justify-between'>
                    <Input
                        className="w-full rounded-xl sm:w-72"
                        placeholder="Filter by name"
                        onChange={(e) => setInput(e.target.value)}
                    />
                    <Button onClick={() => navigate("/admin/companies/create")} className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 shadow-md shadow-violet-200">New Company</Button>
                </div>
                <div className='overflow-hidden rounded-2xl border border-white bg-white shadow-xl shadow-slate-200/60'><CompaniesTable/></div>
            </main>
        </div>
    )
}

export default Companies