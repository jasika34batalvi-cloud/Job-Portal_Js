import React, { useEffect } from 'react'
import Navbar from '../shared/Navbar'
import ApplicantsTable from './ApplicantsTable'
import axios from 'axios';
import { APPLICATION_API_END_POINT } from '@/utils/constant';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setAllApplicants } from '@/redux/applicationSlice';

const Applicants = () => {
    const params = useParams();
    const dispatch = useDispatch();
    const {applicants} = useSelector(store=>store.application);

    useEffect(() => {
        const fetchAllApplicants = async () => {
            try {
                const res = await axios.get(`${APPLICATION_API_END_POINT}/${params.id}/applicants`, { withCredentials: true });
                dispatch(setAllApplicants(res.data.job));
            } catch (error) {
                console.log(error);
            }
        }
        fetchAllApplicants();
    }, []);
    return (
        <div className='min-h-screen'>
            <Navbar />
            <main className='mx-auto max-w-7xl px-4 py-8 animate-page-in'>
                <div className='mb-6 rounded-2xl bg-gradient-to-r from-violet-700 to-fuchsia-500 p-6 text-white shadow-xl shadow-violet-200'>
                    <p className='text-sm font-semibold text-violet-100'>Candidate pipeline</p>
                    <h1 className='mt-1 text-2xl font-extrabold'>Applicants {applicants?.applications?.length}</h1>
                </div>
                <div className='overflow-hidden rounded-2xl border border-white bg-white shadow-xl shadow-slate-200/60'><ApplicantsTable /></div>
            </main>
        </div>
    )
}

export default Applicants