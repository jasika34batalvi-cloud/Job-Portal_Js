import React, { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Avatar, AvatarImage } from "../ui/avatar";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Button } from "../ui/button";
import { Edit2, MoreHorizontal, Trash2 } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { COMPANY_API_END_POINT } from "@/utils/constant";
import { setCompanies } from "@/redux/companySlice";
import { toast } from "sonner";

const CompaniesTable = () => {
  const { companies, searchCompanyByText } = useSelector(
    (store) => store.company
  );
  const [filterCompany, setFilterCompany] = useState(companies);
  const [deletingId, setDeletingId] = useState(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    const filteredCompany = companies.filter((company) => {
      if (!searchCompanyByText) return true;
      return company?.name
        ?.toLowerCase()
        .includes(searchCompanyByText.toLowerCase());
    });
    setFilterCompany(filteredCompany);
  }, [companies, searchCompanyByText]);

  const deleteCompanyHandler = async (company) => {
    const confirmed = window.confirm(
      `Delete "${company.name}"? This will also delete all jobs and applications for this company.`
    );

    if (!confirmed) return;

    try {
      setDeletingId(company._id);

      const response = await axios.delete(
        `${COMPANY_API_END_POINT}/delete/${company._id}`,
        { withCredentials: true }
      );

      if (response.data.success) {
        dispatch(
          setCompanies(companies.filter((item) => item._id !== company._id))
        );
        toast.success(response.data.message);
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to delete company."
      );
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div>
      <Table>
        <TableCaption>A list of your recent registered companies</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Logo</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Date</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {filterCompany.map((company) => (
            <TableRow key={company._id}>
              <TableCell>
                <Avatar>
                  <AvatarImage src={company.logo} />
                </Avatar>
              </TableCell>
              <TableCell>{company.name}</TableCell>
              <TableCell>{company.createdAt?.split("T")[0]}</TableCell>
              <TableCell className="text-right">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" type="button">
                      <MoreHorizontal />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-40">
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="ghost"
                        type="button"
                        onClick={() =>
                          navigate(`/admin/companies/${company._id}`)
                        }
                        className="justify-start gap-2"
                      >
                        <Edit2 className="w-4" />
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        type="button"
                        disabled={deletingId === company._id}
                        onClick={() => deleteCompanyHandler(company)}
                        className="justify-start gap-2 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4" />
                        {deletingId === company._id ? "Deleting..." : "Delete"}
                      </Button>
                    </div>
                  </PopoverContent>
                </Popover>
              </TableCell>
            </TableRow>
          ))}

          {filterCompany.length === 0 && (
            <TableRow>
              <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                No companies found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default CompaniesTable;
