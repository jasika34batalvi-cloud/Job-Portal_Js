import React, { useEffect, useState } from "react";
import Navbar from "../shared/Navbar";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { COMPANY_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { useSelector } from "react-redux";
import useGetCompanyById from "@/hooks/useGetCompanyById";

const readFileAsDataUrl = (file) =>
  new Promise((resolve, reject) => {
    if (!file) {
      resolve("");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read logo."));
    reader.readAsDataURL(file);
  });

const CompanySetup = () => {
  const params = useParams();
  const navigate = useNavigate();

  useGetCompanyById(params.id);

  const { singleCompany } = useSelector((store) => store.company);
  const [loading, setLoading] = useState(false);

  const [input, setInput] = useState({
    name: "",
    description: "",
    website: "",
    location: "",
    logo: "",
  });

  useEffect(() => {
    if (!singleCompany) return;

    setInput({
      name: singleCompany.name || "",
      description: singleCompany.description || "",
      website: singleCompany.website || "",
      location: singleCompany.location || "",
      logo: singleCompany.logo || "",
    });
  }, [singleCompany]);

  const changeEventHandler = (e) => {
    setInput((previous) => ({
      ...previous,
      [e.target.name]: e.target.value,
    }));
  };

  const changeFileHandler = async (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error("Logo must be smaller than 2MB.");
      return;
    }

    try {
      const logo = await readFileAsDataUrl(file);

      setInput((previous) => ({
        ...previous,
        logo,
      }));
    } catch {
      toast.error("Unable to read company logo.");
    }
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const response = await axios.put(
        `${COMPANY_API_END_POINT}/update/${params.id}`,
        input,
        { withCredentials: true }
      );

      if (response.data.success) {
        toast.success(response.data.message);
        navigate("/admin/companies");
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to update company."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='min-h-screen'>
      <Navbar />

      <div className="mx-auto max-w-xl px-4 py-8 animate-page-in">
        <form onSubmit={submitHandler} className="rounded-3xl border border-white bg-white p-6 shadow-xl shadow-slate-200/60 sm:p-8">

          <div className="flex items-center gap-5 p-8">
            <Button
              type="button"
              onClick={() => navigate("/admin/companies")}
              variant="outline"
              className="flex items-center gap-2 text-gray-500 font-semibold"
            >
              <ArrowLeft />
              <span>Back</span>
            </Button>

            <h1 className="font-bold text-xl">
              Company Setup
            </h1>
          </div>

          <div className="grid grid-cols-2 gap-4">

            <div>
              <Label>Company Name</Label>
              <Input
                type="text"
                name="name"
                value={input.name}
                onChange={changeEventHandler}
              />
            </div>

            <div>
              <Label>Description</Label>
              <Input
                type="text"
                name="description"
                value={input.description}
                onChange={changeEventHandler}
              />
            </div>

            <div>
              <Label>Website</Label>
              <Input
                type="text"
                name="website"
                value={input.website}
                onChange={changeEventHandler}
              />
            </div>

            <div>
              <Label>Location</Label>
              <Input
                type="text"
                name="location"
                value={input.location}
                onChange={changeEventHandler}
              />
            </div>

            <div>
              <Label>Logo</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={changeFileHandler}
              />
            </div>

          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full my-4"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Please wait
              </>
            ) : (
              "Update"
            )}
          </Button>

        </form>
      </div>
    </div>
  );
};

export default CompanySetup;
