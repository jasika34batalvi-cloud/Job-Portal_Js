import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const { user, authChecked } = useSelector((store) => store.auth);
  const navigate = useNavigate();

  useEffect(() => {
    if (authChecked && (!user || user.role !== "recruiter")) {
      navigate("/", { replace: true });
    }
  }, [authChecked, user, navigate]);

  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Checking authentication...</p>
      </div>
    );
  }

  if (!user || user.role !== "recruiter") {
    return null;
  }

  return children;
};

export default ProtectedRoute;
