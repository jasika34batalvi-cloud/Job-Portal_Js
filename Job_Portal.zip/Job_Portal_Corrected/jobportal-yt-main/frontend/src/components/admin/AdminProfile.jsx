import React, { useState } from "react";
import { useSelector } from "react-redux";
import { motion } from "framer-motion";
import {
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Mail,
  Pen,
  Phone,
  ShieldCheck,
  Sparkles,
  UserRound,
} from "lucide-react";
import Navbar from "../shared/Navbar";
import UpdateProfileDialog from "../UpdateProfileDialog";
import { Avatar, AvatarImage, AvatarFallback as AvatarFallbackUi } from "../ui/avatar";
import useGetAllAdminJobs from "@/hooks/useGetAllAdminJobs";
import useGetAllCompanies from "@/hooks/useGetAllCompanies";

const AdminProfile = () => {
  useGetAllAdminJobs();
  useGetAllCompanies();

  const { user } = useSelector((store) => store.auth);
  const jobs = useSelector((store) => store.job.allAdminJobs || []);
  const companies = useSelector((store) => store.company.companies || []);
  const [open, setOpen] = useState(false);

  const stats = [
    { label: "Posted Jobs", value: jobs.length, icon: BriefcaseBusiness },
    { label: "Companies", value: companies.length, icon: Building2 },
  ];

  return (
    <div className="min-h-screen bg-slate-50/70">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-violet-600">
            <Sparkles size={16} /> Recruiter workspace
          </p>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">Admin Profile</h1>
          <p className="mt-2 text-slate-500">Manage your recruiter identity and keep your hiring workspace up to date.</p>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-[1.4fr_.6fr]">
          <motion.section
            initial={{ opacity: 0, x: -25 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="overflow-hidden rounded-3xl border border-white bg-white shadow-xl shadow-violet-100/60"
          >
            <div className="relative h-36 bg-gradient-to-r from-violet-700 via-purple-600 to-fuchsia-500">
              <div className="absolute -right-12 -top-20 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
              <div className="absolute bottom-0 left-0 h-20 w-full bg-gradient-to-t from-black/10 to-transparent" />
            </div>

            <div className="relative px-6 pb-7 sm:px-8">
              <div className="-mt-14 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div className="flex items-end gap-4">
                  <Avatar className="h-28 w-28 border-4 border-white shadow-xl">
                    <AvatarImage src={user?.profile?.profilePhoto} alt={user?.fullname || "Profile"} />
                    <AvatarFallbackUi className="bg-violet-100 text-2xl font-bold text-violet-700">
                      {user?.fullname?.charAt(0)?.toUpperCase() || "A"}
                    </AvatarFallbackUi>
                  </Avatar>
                  <div className="pb-1">
                    <h2 className="text-2xl font-bold text-slate-900">{user?.fullname || "Recruiter"}</h2>
                    <div className="mt-1 flex items-center gap-2 text-sm text-slate-500">
                      <ShieldCheck size={16} className="text-emerald-500" /> Recruiter account · company verification managed by platform admin
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setOpen(true)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-violet-700"
                >
                  <Pen size={16} /> Edit Profile
                </button>
              </div>

              <div className="mt-8 grid gap-3 sm:grid-cols-2">
                <Info icon={Mail} label="Email" value={user?.email} />
                <Info icon={Phone} label="Phone" value={user?.phoneNumber} />
                <Info icon={ShieldCheck} label="Account" value="Active & authenticated" />
                <Info icon={CalendarDays} label="Role" value="Recruiter / Admin" />
              </div>

              <div className="mt-7 rounded-2xl bg-slate-50 p-5">
                <p className="mb-2 flex items-center gap-2 text-sm font-bold text-slate-800">
                  <UserRound size={17} className="text-violet-600" /> About
                </p>
                <p className="leading-7 text-slate-500">{user?.profile?.bio || "Add a short professional bio from Edit Profile."}</p>
              </div>
            </div>
          </motion.section>

          <motion.aside
            initial={{ opacity: 0, x: 25 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.18 }}
            className="space-y-4"
          >
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  whileHover={{ y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="rounded-2xl border border-white bg-white p-5 shadow-lg shadow-slate-200/70"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                      <p className="mt-1 text-3xl font-extrabold text-slate-900">{stat.value}</p>
                    </div>
                    <div className="rounded-2xl bg-gradient-to-br from-violet-100 to-fuchsia-100 p-3 text-violet-700">
                      <Icon size={24} />
                    </div>
                  </div>
                </motion.div>
              );
            })}
            <div className="rounded-2xl bg-gradient-to-br from-violet-700 to-fuchsia-500 p-6 text-white shadow-xl shadow-violet-200">
              <Building2 className="mb-4" size={27} />
              <h3 className="text-lg font-bold">Build your hiring brand</h3>
              <p className="mt-2 text-sm leading-6 text-violet-100">Complete your profile and company information to give candidates a stronger first impression.</p>
            </div>
          </motion.aside>
        </div>
      </main>

      <UpdateProfileDialog open={open} setOpen={setOpen} />
    </div>
  );
};

const Info = ({ icon: Icon, label, value }) => (
  <div className="rounded-2xl border border-slate-100 bg-white p-4 transition hover:border-violet-200 hover:shadow-md">
    <div className="flex items-center gap-3">
      <span className="rounded-xl bg-violet-50 p-2 text-violet-600"><Icon size={17} /></span>
      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">{label}</p>
        <p className="mt-1 truncate font-medium text-slate-700">{value || "Not added"}</p>
      </div>
    </div>
  </div>
);

export default AdminProfile;
