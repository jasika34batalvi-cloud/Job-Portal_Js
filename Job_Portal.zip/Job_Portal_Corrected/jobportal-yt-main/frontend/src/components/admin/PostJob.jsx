import React, { useState } from "react";
import Navbar from "../shared/Navbar";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { useSelector } from "react-redux";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import axios from "axios";
import { JOB_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";

const PostJob = () => {
  const [input, setInput] = useState({
    title: "",
    description: "",
    requirements: "",
    salary: "",
    location: "",
    jobType: "",
    category: "",
    workMode: "",
    experience: "",
    position: 1,
    companyId: "",
  });

  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { companies } = useSelector((store) => store.company);

  const changeEventHandler = (e) => {
    setInput((previous) => ({
      ...previous,
      [e.target.name]: e.target.value,
    }));
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    if (!input.companyId) {
      toast.error("Please select a company.");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post(
        `${JOB_API_END_POINT}/post`,
        input,
        { withCredentials: true }
      );

      if (response.data.success) {
        toast.success(response.data.message);
        navigate("/admin/jobs");
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to post job."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='min-h-screen'>
      <Navbar />

      <div className="flex w-full items-center justify-center px-4 py-8 animate-page-in">
        <form
          onSubmit={submitHandler}
          className="w-full max-w-4xl rounded-3xl border border-white bg-white p-6 shadow-2xl shadow-violet-100/70 sm:p-8"
        >
          <div className="grid grid-cols-2 gap-2">

            <div>
              <Label>Title</Label>
              <Input
                type="text"
                name="title"
                value={input.title}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Input
                type="text"
                name="description"
                value={input.description}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            <div>
              <Label>Requirements</Label>
              <Input
                type="text"
                name="requirements"
                value={input.requirements}
                onChange={changeEventHandler}
                placeholder="React, Node.js, MongoDB"
                className="my-1"
              />
            </div>

            <div>
              <Label>Salary (LPA)</Label>
              <Input
                type="number"
                min="0"
                name="salary"
                value={input.salary}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            <div>
              <Label>Location</Label>
              <Input
                type="text"
                name="location"
                value={input.location}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            <div>
              <Label>Job Type</Label>
              <Input
                type="text"
                name="jobType"
                value={input.jobType}
                onChange={changeEventHandler}
                placeholder="Full-time"
                className="my-1"
              />
            </div>

            <div>
              <Label>Job Category</Label>
              <Input type="text" name="category" value={input.category} onChange={changeEventHandler} placeholder="Software Engineer" className="my-1"/>
            </div>

            <div>
              <Label>Work Mode</Label>
              <select name="workMode" value={input.workMode} onChange={changeEventHandler} className="my-1 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm">
                <option value="">Select work mode</option>
                <option value="Remote">Remote</option>
                <option value="Hybrid">Hybrid</option>
                <option value="On-site">On-site</option>
              </select>
            </div>

            <div>
              <Label>Experience Level (years)</Label>
              <Input
                type="number"
                min="0"
                name="experience"
                value={input.experience}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            <div>
              <Label>No. of Positions</Label>
              <Input
                type="number"
                min="1"
                name="position"
                value={input.position}
                onChange={changeEventHandler}
                className="my-1"
              />
            </div>

            {companies.length > 0 && (
              <div className="col-span-2">
                <Label>Company</Label>

                <Select
                  value={input.companyId}
                  onValueChange={(value) =>
                    setInput((previous) => ({
                      ...previous,
                      companyId: value,
                    }))
                  }
                >
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue placeholder="Select a Company" />
                  </SelectTrigger>

                  <SelectContent>
                    <SelectGroup>
                      {companies.map((company) => (
                        <SelectItem
                          value={company._id}
                          key={company._id}
                        >
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <Button
            type="submit"
            disabled={loading || companies.length === 0}
            className="w-full my-4"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Please wait
              </>
            ) : (
              "Post New Job"
            )}
          </Button>

          {companies.length === 0 && (
            <p className="text-xs text-red-600 font-bold text-center my-3">
              Please register a company first before posting a job.
            </p>
          )}
        </form>
      </div>
    </div>
  );
};

export default PostJob;
