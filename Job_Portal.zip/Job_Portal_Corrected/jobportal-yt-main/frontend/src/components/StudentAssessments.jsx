import React, { useCallback, useEffect, useState } from "react";
import axios from "axios";
import Navbar from "./shared/Navbar";
import { CAREER_API_END_POINT } from "@/utils/constant";
import { toast } from "sonner";
import { ClipboardCheck, Clock3 } from "lucide-react";

const StudentAssessments = () => {
  const [assessments, setAssessments] = useState([]);
  const [responses, setResponses] = useState({});
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${CAREER_API_END_POINT}/assessments`, { withCredentials: true });
      setAssessments(res.data.assessments || []);
    } catch (error) { toast.error(error.response?.data?.message || "Unable to load assessments."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const submit = async (item) => {
    try {
      await axios.post(`${CAREER_API_END_POINT}/assessments/${item._id}/submit`, { response: responses[item._id] || "" }, { withCredentials: true });
      toast.success("Assessment submitted successfully.");
      await load();
    } catch (error) { toast.error(error.response?.data?.message || "Unable to submit assessment."); }
  };

  return <div className="min-h-screen bg-slate-50"><Navbar/><main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6">
    <header className="rounded-3xl bg-gradient-to-r from-violet-700 to-fuchsia-600 p-7 text-white shadow-xl shadow-violet-100"><p className="text-sm font-semibold text-violet-100">Career toolkit</p><h1 className="mt-1 text-3xl font-black">My assessments</h1><p className="mt-2 text-sm text-violet-100">Review tasks from recruiters, submit your response and track your results.</p></header>
    {loading ? <p className="py-12 text-center text-slate-500">Loading assessments…</p> : assessments.length === 0 ? <div className="rounded-2xl border border-slate-100 bg-white p-12 text-center"><ClipboardCheck className="mx-auto text-violet-500" size={36}/><h2 className="mt-3 font-bold text-slate-900">No assessments yet</h2><p className="mt-1 text-sm text-slate-500">When a recruiter assigns an assessment, it will appear here.</p></div> : <div className="space-y-4">{assessments.map((a) => <article key={a._id} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-lg font-extrabold text-slate-900">{a.title}</h2><p className="mt-1 text-sm text-slate-500">{a.application?.job?.title || "Job application"}</p></div><span className={`rounded-full px-3 py-1 text-xs font-bold capitalize ${a.status === "reviewed" ? "bg-emerald-50 text-emerald-700" : a.status === "submitted" ? "bg-amber-50 text-amber-700" : "bg-violet-50 text-violet-700"}`}>{a.status}</span></div>{a.dueAt && <p className="mt-3 flex items-center gap-2 text-xs text-slate-500"><Clock3 size={14}/> Due {new Date(a.dueAt).toLocaleString()}</p>}<div className="mt-4 whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm leading-6 text-slate-700">{a.instructions}</div>{a.status === "assigned" && <div className="mt-4 space-y-3"><label className="block text-sm font-bold text-slate-700">Your response</label><textarea rows={5} maxLength={20000} value={responses[a._id] || ""} onChange={(e) => setResponses((prev) => ({ ...prev, [a._id]: e.target.value }))} placeholder="Write your assessment response here…" className="w-full rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-violet-400"/><button onClick={() => submit(a)} className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-bold text-white hover:bg-violet-700">Submit assessment</button></div>}{a.status !== "assigned" && <div className="mt-4 rounded-xl border border-slate-100 p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Your submitted response</p><p className="mt-2 whitespace-pre-wrap text-sm text-slate-700">{a.response}</p>{a.status === "reviewed" && <div className="mt-4 rounded-lg bg-emerald-50 p-3"><p className="font-extrabold text-emerald-800">Score: {a.score}/100</p>{a.reviewerFeedback && <p className="mt-1 text-sm text-emerald-800">{a.reviewerFeedback}</p>}</div>}</div>}</article>)}</div>}
  </main></div>;
};
export default StudentAssessments;
