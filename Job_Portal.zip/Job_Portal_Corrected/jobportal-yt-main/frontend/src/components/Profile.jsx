import React, { useState } from "react";
import Navbar from "./shared/Navbar";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Contact, Mail, Pen, FileText, Sparkles } from "lucide-react";
import { Badge } from "./ui/badge";
import AppliedJobTable from "./AppliedJobTable";
import UpdateProfileDialog from "./UpdateProfileDialog";
import { useSelector } from "react-redux";
import useGetAppliedJobs from "@/hooks/useGetAppliedJobs";
import { motion } from "framer-motion";

const Profile = () => {
  useGetAppliedJobs();
  const [open, setOpen] = useState(false);
  const { user } = useSelector((store) => store.auth);
  const skills = user?.profile?.skills || [];

  return (
    <div className="min-h-screen bg-slate-50/70">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="mb-7">
          <p className="flex items-center gap-2 text-sm font-semibold text-violet-600"><Sparkles size={16} /> Your career profile</p>
          <h1 className="mt-2 text-3xl font-extrabold text-slate-900">Profile & Applications</h1>
          <p className="mt-2 text-slate-500">Keep your profile polished and track the jobs you have applied for.</p>
        </motion.div>

        <motion.section
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08 }}
          className="overflow-hidden rounded-3xl border border-white bg-white shadow-xl shadow-violet-100/60"
        >
          <div className="h-32 bg-gradient-to-r from-violet-700 via-purple-600 to-fuchsia-500" />
          <div className="px-6 pb-7 sm:px-8">
            <div className="-mt-14 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
              <div className="flex items-end gap-4">
                <Avatar className="h-28 w-28 border-4 border-white shadow-xl">
                  <AvatarImage src={user?.profile?.profilePhoto} alt={user?.fullname || "Profile"} />
                  <AvatarFallback className="bg-violet-100 text-2xl font-bold text-violet-700">{user?.fullname?.charAt(0)?.toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <div className="pb-1">
                  <h2 className="text-2xl font-bold text-slate-900">{user?.fullname}</h2>
                  <p className="mt-1 text-sm text-slate-500">{user?.profile?.bio || "Add your professional bio."}</p>
                </div>
              </div>
              <Button onClick={() => setOpen(true)} className="rounded-xl bg-slate-900 px-5 hover:bg-violet-700"><Pen className="mr-2 h-4 w-4" /> Edit Profile</Button>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              <Info icon={Mail} value={user?.email} />
              <Info icon={Contact} value={user?.phoneNumber} />
            </div>

            <div className="mt-7">
              <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-slate-500">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {skills.length ? skills.map((item) => <Badge key={item} className="rounded-full bg-violet-50 px-3 py-1 text-violet-700 hover:bg-violet-100">{item}</Badge>) : <span className="text-sm text-slate-400">No skills added yet.</span>}
              </div>
            </div>

            <div className="mt-7 rounded-2xl bg-slate-50 p-5">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-800"><FileText size={18} className="text-violet-600" /> Resume</div>
              {user?.profile?.resume ? (
                <a target="_blank" rel="noreferrer" href={user.profile.resume} className="mt-2 inline-block font-medium text-violet-600 hover:underline">
                  {user.profile.resumeOriginalName || "View resume"}
                </a>
              ) : <p className="mt-2 text-sm text-slate-400">No resume uploaded yet.</p>}
            </div>
          </div>
        </motion.section>

        <motion.section initial={{ opacity: 0, y: 25 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }} className="mt-8">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-slate-900">Applied Jobs</h2>
            <p className="text-sm text-slate-500">Your latest applications appear below.</p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-white bg-white shadow-lg shadow-slate-200/60">
            <AppliedJobTable />
          </div>
        </motion.section>
      </main>
      <UpdateProfileDialog open={open} setOpen={setOpen} />
    </div>
  );
};

const Info = ({ icon: Icon, value }) => (
  <div className="rounded-2xl border border-slate-100 bg-white p-4 transition hover:border-violet-200 hover:shadow-md">
    <div className="flex items-center gap-3"><span className="rounded-xl bg-violet-50 p-2 text-violet-600"><Icon size={17} /></span><span className="truncate text-sm font-medium text-slate-700">{value || "Not added"}</span></div>
  </div>
);

export default Profile;
