import React, { useMemo, useState } from "react";
import { Button } from "./ui/button";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { Avatar, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { JOB_API_END_POINT } from "@/utils/constant";
import { setUser } from "@/redux/authSlice";
import { toast } from "sonner";

const Job = ({ job }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user } = useSelector((store) => store.auth);
  const [saving, setSaving] = useState(false);

  const isSaved = useMemo(
    () =>
      Boolean(
        user?.savedJobs?.some(
          (id) => String(id?._id || id) === String(job?._id)
        )
      ),
    [user?.savedJobs, job?._id]
  );

  const daysAgoFunction = (mongodbTime) => {
    if (!mongodbTime) return 0;
    const createdAt = new Date(mongodbTime);
    const currentTime = new Date();
    return Math.max(
      0,
      Math.floor((currentTime - createdAt) / (1000 * 24 * 60 * 60))
    );
  };

  const saveForLaterHandler = async () => {
    if (!user) {
      toast.error("Please login as a student to save jobs.");
      navigate("/login");
      return;
    }

    if (user.role !== "student") {
      toast.error("Only student accounts can save jobs.");
      return;
    }

    try {
      setSaving(true);

      const res = isSaved
        ? await axios.delete(`${JOB_API_END_POINT}/save/${job._id}`, {
            withCredentials: true,
          })
        : await axios.post(
            `${JOB_API_END_POINT}/save/${job._id}`,
            {},
            { withCredentials: true }
          );

      if (res.data.success) {
        const currentSaved = Array.isArray(user.savedJobs) ? user.savedJobs : [];
        const nextSaved = isSaved
          ? currentSaved.filter(
              (id) => String(id?._id || id) !== String(job._id)
            )
          : [...currentSaved, job._id];

        dispatch(setUser({ ...user, savedJobs: nextSaved }));
        toast.success(res.data.message);
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Unable to update saved jobs."
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-5 rounded-md shadow-xl bg-white border border-gray-100 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-500">
          {daysAgoFunction(job?.createdAt) === 0
            ? "Today"
            : `${daysAgoFunction(job?.createdAt)} days ago`}
        </p>

        <Button
          type="button"
          variant="outline"
          className={`rounded-full transition-all ${
            isSaved ? "border-[#7209b7] text-[#7209b7]" : ""
          }`}
          size="icon"
          onClick={saveForLaterHandler}
          disabled={saving}
          title={isSaved ? "Remove from saved jobs" : "Save for later"}
        >
          {isSaved ? <BookmarkCheck /> : <Bookmark />}
        </Button>
      </div>

      <div className="flex items-center gap-2 my-2">
        <Button className="p-6" variant="outline" size="icon" type="button">
          <Avatar>
            <AvatarImage src={job?.company?.logo} />
          </Avatar>
        </Button>
        <div>
          <h1 className="font-medium text-lg">{job?.company?.name}</h1>
          <p className="text-sm text-gray-500">
            {job?.location || "India"}
          </p>
        </div>
      </div>

      <div>
        <h1 className="font-bold text-lg my-2">{job?.title}</h1>
        <p className="text-sm text-gray-600 line-clamp-3">
          {job?.description}
        </p>
      </div>

      <div className="flex items-center gap-2 mt-4 flex-wrap">
        <Badge className="text-blue-700 font-bold" variant="ghost">
          {job?.position} Positions
        </Badge>
        <Badge className="text-[#F83002] font-bold" variant="ghost">
          {job?.jobType}
        </Badge>
        <Badge className="text-[#7209b7] font-bold" variant="ghost">
          {job?.salary}LPA
        </Badge>
      </div>

      <div className="flex items-center gap-4 mt-4">
        <Button
          onClick={() => navigate(`/description/${job?._id}`)}
          variant="outline"
        >
          Details
        </Button>
        <Button
          type="button"
          onClick={saveForLaterHandler}
          disabled={saving}
          className="bg-[#7209b7] hover:bg-[#5f32ad]"
        >
          {isSaved ? "Saved" : "Save For Later"}
        </Button>
      </div>
    </div>
  );
};

export default Job;
