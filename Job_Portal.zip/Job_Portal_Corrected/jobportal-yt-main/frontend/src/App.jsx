import React, { useEffect } from "react";
import { createBrowserRouter, RouterProvider, Link } from "react-router-dom";
import axios from "axios";
import { useDispatch } from "react-redux";

import Login from "./components/auth/Login";
import Signup from "./components/auth/Signup";
import Home from "./components/Home";
import About from "./components/About";
import Contact from "./components/Contact";
import Jobs from "./components/Jobs";
import Browse from "./components/Browse";
import Profile from "./components/Profile";
import AdminProfile from "./components/admin/AdminProfile";
import JobDescription from "./components/JobDescription";
import ApplicationTracking from "./components/ApplicationTracking";
import NotificationsCalendar from "./components/NotificationsCalendar";
import InterviewPreparation from "./components/InterviewPreparation";
import HiringManagement from "./components/admin/HiringManagement";
import StudentAssessments from "./components/StudentAssessments";
import Companies from "./components/admin/Companies";
import CompanyCreate from "./components/admin/CompanyCreate";
import CompanySetup from "./components/admin/CompanySetup";
import AdminJobs from "./components/admin/AdminJobs";
import PostJob from "./components/admin/PostJob";
import Applicants from "./components/admin/Applicants";
import ProtectedRoute from "./components/admin/ProtectedRoute";
import ResumeAnalyzer from "./components/ResumeAnalyzer";
import AdminDashboard from "./components/admin/AdminDashboard";
import AdminContactMessages from "./components/admin/AdminContactMessages";
import AdminOnlyRoute from "./components/admin/AdminOnlyRoute";

import { USER_API_END_POINT } from "@/utils/constant";
import { setAuthChecked, setUser } from "@/redux/authSlice";

const NotFound = () => (
  <main className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
    <h1 className="text-5xl font-black text-violet-700">404</h1>
    <p className="mt-3 text-lg font-semibold text-slate-700">
      This page could not be found.
    </p>
    <Link
      to="/"
      className="mt-6 rounded-xl bg-violet-700 px-5 py-3 font-bold text-white"
    >
      Back to home
    </Link>
  </main>
);

const appRouter = createBrowserRouter([
  { path: "/", element: <Home /> },
  { path: "/about", element: <About /> },
  { path: "/contact", element: <Contact /> },
  { path: "/admin/contact-messages", element: (<AdminOnlyRoute><AdminContactMessages /></AdminOnlyRoute>) },
  { path: "/login", element: <Login /> },
  { path: "/signup", element: <Signup /> },
  { path: "/resume-analyzer", element: <ResumeAnalyzer /> },
  { path: "/jobs", element: <Jobs /> },
  { path: "/description/:id", element: <JobDescription /> },
  { path: "/browse", element: <Browse /> },
  { path: "/profile", element: <Profile /> },
  { path: "/applications", element: <ApplicationTracking /> },
  { path: "/interviews", element: <NotificationsCalendar /> },
  { path: "/interview-preparation", element: <InterviewPreparation /> },
  { path: "/assessments", element: <StudentAssessments /> },

  {
    path: "/admin/dashboard",
    element: (
      <AdminOnlyRoute>
        <AdminDashboard />
      </AdminOnlyRoute>
    ),
  },
  {
    path: "/admin/interviews",
    element: (
      <ProtectedRoute>
        <NotificationsCalendar />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/hiring",
    element: (
      <ProtectedRoute>
        <HiringManagement mode="hiring" />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/assignments",
    element: (
      <ProtectedRoute>
        <HiringManagement mode="assignments" />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/profile",
    element: (
      <ProtectedRoute>
        <AdminProfile />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/companies",
    element: (
      <ProtectedRoute>
        <Companies />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/companies/create",
    element: (
      <ProtectedRoute>
        <CompanyCreate />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/companies/:id",
    element: (
      <ProtectedRoute>
        <CompanySetup />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/jobs",
    element: (
      <ProtectedRoute>
        <AdminJobs />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/jobs/create",
    element: (
      <ProtectedRoute>
        <PostJob />
      </ProtectedRoute>
    ),
  },
  {
    path: "/admin/jobs/:id/applicants",
    element: (
      <ProtectedRoute>
        <Applicants />
      </ProtectedRoute>
    ),
  },
  { path: "*", element: <NotFound /> },
]);

class AppErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error) {
    console.error("Application rendering error:", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-5 text-center">
          <h1 className="text-2xl font-black text-slate-900">
            Something went wrong
          </h1>
          <p className="mt-2 max-w-lg text-sm text-slate-600">
            The page could not be displayed. Check the browser console for the
            error details, then reload the application.
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-5 rounded-xl bg-violet-700 px-5 py-3 font-bold text-white"
          >
            Reload page
          </button>
        </main>
      );
    }

    return this.props.children;
  }
}

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    let active = true;

    const loadSession = async () => {
      try {
        const response = await axios.get(`${USER_API_END_POINT}/me`, {
          withCredentials: true,
        });

        if (active && response.data?.success) {
          dispatch(setUser(response.data.user || null));
        } else if (active) {
          dispatch(setUser(null));
        }
      } catch (error) {
        if (active) dispatch(setUser(null));
      } finally {
        if (active) dispatch(setAuthChecked(true));
      }
    };

    loadSession();

    return () => {
      active = false;
    };
  }, [dispatch]);

  return (
    <AppErrorBoundary>
      <div className="min-h-screen">
        <RouterProvider router={appRouter} />
      </div>
    </AppErrorBoundary>
  );
}

export default App;
