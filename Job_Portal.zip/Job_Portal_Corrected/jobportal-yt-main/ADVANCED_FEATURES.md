# Advanced Job Portal Features

This update adds/extends three recruiter and student workflows.

## 1. Advanced Recruitment Analytics
- Recruiter-only analytics endpoint: `GET /api/v1/career/hiring/analytics`
- KPI cards for jobs, candidates, new candidates this month, interviews, hired and hire rate.
- Hiring-stage funnel counts.
- Six-month application activity chart.
- Assessment completion and average reviewed score.

## 2. Application Tracking
- Student page: `/applications`
- Displays application totals and the current hiring stage: Applied, Shortlisted, Assessment, Interview, Offer, Hired or Rejected.
- Recruiter stage updates are reflected in the student's tracking page and application notifications.

## 3. Candidate Management
- Recruiter page: `/admin/hiring` (Navbar: Analytics & Candidates)
- Search by candidate name, email, phone, job title, company or skills.
- Filter by hiring stage and job.
- View candidate contact details, skills and uploaded resume.
- Change pipeline stage, add private notes and save interview feedback.

## API endpoints
- `GET /api/v1/career/candidates` (recruiter)
- `GET /api/v1/career/hiring/analytics` (recruiter)
- `PATCH /api/v1/career/hiring/applications/:id/stage` (recruiter)
- `POST /api/v1/career/hiring/applications/:id/notes` (recruiter)
- `POST /api/v1/career/hiring/applications/:id/feedback` (recruiter)
- `GET /api/v1/application/get` (student)

## Run locally
Backend:
```bash
cd backend
npm install
npm run dev
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```

Configure the existing backend `.env` file with MongoDB URI, JWT secret, Cloudinary credentials and `CLIENT_URL=http://localhost:5173`. Do not replace the project's existing environment values with sample credentials.
