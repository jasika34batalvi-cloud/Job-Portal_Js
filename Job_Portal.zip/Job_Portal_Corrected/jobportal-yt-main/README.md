# Job Portal (MongoDB + JWT)

A full-stack React, Express and MongoDB job portal. This source package excludes `node_modules` and local secrets; install dependencies before running.

## Requirements
- Node.js 18 or newer
- MongoDB local instance or MongoDB Atlas
- npm

## 1. Configure backend
```bash
cd backend
npm install
```
Copy `.env.example` to `.env`, then set your real MongoDB connection string and a strong JWT secret. Never commit `.env`.

```bash
npm run dev
```
Backend: `http://localhost:8000`  
Health check: `http://localhost:8000/api/health`

## 2. Configure frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Frontend: `http://localhost:5173`

## Job search filters
The `/api/v1/job/get` endpoint supports:
- `keyword`
- `jobType`
- `location`
- `salary` (for example `5-10` or `25+`, values are LPA)
- `experience` (for example `0`, `1-2`, `3-5`, `5+`)
- `category`
- `postedWithin` (days: 1, 3, 7, 30)
- `workMode` (`Remote`, `Hybrid`, `On-site`)
- `company`
- `skills` (comma-separated)
- `sort` (`newest`, `oldest`, `salaryHigh`, `salaryLow`)

Example:
`GET /api/v1/job/get?jobType=Full-time&location=Ludhiana&salary=5-10&postedWithin=7&sort=newest`

Filters are composed as MongoDB query conditions and can be combined. Salary is stored in LPA.

## Assignments
Recruiters can create, review and delete their own assignments from `/admin/assignments` (also available in Hiring). Delete uses:
`DELETE /api/v1/career/assessments/:id`
The route requires recruiter authentication and only deletes an assessment owned by the signed-in recruiter. Students continue to see assigned work at `/assessments`.

## Notes
- Existing jobs remain compatible. `category` and `workMode` are optional fields on the Job model; older records may not match category/work-mode filters until edited or recreated with those values.
- API authentication continues to use the existing JWT/cookie flow.
- For MongoDB Atlas, add the machine's public IP to the Atlas Network Access allowlist.


## Latest advanced upgrade
See `ADMIN_SETUP.md` for administrator account setup and API details. This version adds theme switching, an animated landing page, a local resume-to-job skill matcher, and an administrator dashboard with recruiter company verification.


## About Us and Contact Us pages
- Public pages: `/about` and `/contact` (available without login).
- Contact form endpoint: `POST /api/v1/contact`. Messages are validated and saved in MongoDB in the `contactmessages` collection.
- Contact page includes FAQ accordions, a Google Maps preview, social profile links and an optional WhatsApp link.
- Before production, replace the demo support email, add the official phone number and office address, update the Google Maps embed to the verified office location, and replace social links / WhatsApp destination with official business accounts. The map currently displays a general India preview, not a verified office location.
