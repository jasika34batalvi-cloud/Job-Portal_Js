# JobPortal MongoDB + JWT — Postman Flow

Base URL: `http://localhost:8000/api/v1`

## 1. Health
GET `/../api/health`  
Use: `http://localhost:8000/api/health`

## 2. Student signup
POST `/user/register`
```json
{
  "fullname": "Student One",
  "email": "student@example.com",
  "phoneNumber": "9876543210",
  "password": "password123",
  "role": "student"
}
```

## 3. Recruiter signup
POST `/user/register`
```json
{
  "fullname": "Recruiter One",
  "email": "recruiter@example.com",
  "phoneNumber": "9876543211",
  "password": "password123",
  "role": "recruiter"
}
```

## 4. Login
POST `/user/login`
```json
{
  "email": "student@example.com",
  "password": "password123",
  "role": "student"
}
```
The response includes `token`, and the server also sets the `token` HTTP-only cookie.

For Postman, you can either let Postman keep the cookie or use:
`Authorization: Bearer <token>`

## 5. Recruiter login
POST `/user/login`
```json
{
  "email": "recruiter@example.com",
  "password": "password123",
  "role": "recruiter"
}
```

## 6. Register company
POST `/company/register`
```json
{
  "companyName": "Tech Solutions Pvt Ltd"
}
```
Copy `company._id` from the response as `COMPANY_ID`.

## 7. Create job
POST `/job/post`
```json
{
  "title": "MERN Stack Developer",
  "description": "Build and maintain full-stack web applications.",
  "requirements": "React, Node.js, Express, MongoDB",
  "salary": 8,
  "location": "Ludhiana",
  "jobType": "Full-time",
  "experience": 1,
  "position": 2,
  "companyId": "COMPANY_ID"
}
```
Copy `job._id` from the response as `JOB_ID`.

## 8. Get all jobs
GET `/job/get`

## 9. Student apply
Login as the student first, then:
POST `/application/apply/JOB_ID`

Body:
```json
{}
```

Expected response:
```json
{
  "success": true,
  "message": "Job applied successfully."
}
```

The older GET `/application/apply/JOB_ID` remains supported for compatibility.

## 10. Student applications
GET `/application/get`

## 11. Save job for later
As a logged-in student:
POST `/job/save/JOB_ID`

## 12. Saved jobs
GET `/job/saved`

## 13. Remove saved job
DELETE `/job/save/JOB_ID`

## 14. Recruiter applicants
As the recruiter who owns the job:
GET `/application/JOB_ID/applicants`

## 15. Update application status
POST `/application/status/APPLICATION_ID/update`
```json
{
  "status": "accepted"
}
```

## 16. Delete company
As the recruiter who owns the company:
DELETE `/company/delete/COMPANY_ID`

This removes the company, its jobs, their applications, and saved-job references to those jobs.
